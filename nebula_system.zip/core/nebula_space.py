"""
Implementación de la clase NebulaSpace para NEBULA.

Esta clase gestiona el entorno espacial dinámico donde existen y se conectan
las neuronas cuánticas, clusters y sectores.
"""

import logging
import time
import random
from typing import Any, Dict, List, Optional, Tuple, Union, Set
from collections import defaultdict

import numpy as np
import torch
import networkx as nx
from scipy.spatial import cKDTree
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler

from core.quantum_neuron import QuantumNeuron
from core.cluster import Cluster, Sector
from utils.config import PARAMETERS
from utils.helpers import convert_to_numpy

logger = logging.getLogger("NEBULA.NebulaSpace")

class NebulaSpace:
    """
    Gestiona el entorno espacial dinámico para las neuronas, clusters y sectores de NEBULA.
    
    NebulaSpace proporciona un entorno tridimensional donde las neuronas pueden:
    - Existir en posiciones específicas
    - Conectarse entre sí
    - Emitir y recibir señales (luz)
    - Organizarse en clusters y sectores
    - Evolucionar y adaptarse con el tiempo
    """
    
    def __init__(
        self,
        dimensions: Tuple[int, int, int] = PARAMETERS["SPACE_DIMENSIONS"],
        device: torch.device = PARAMETERS["DEVICE"]
    ):
        """
        Inicializa el espacio de NEBULA.
        
        Args:
            dimensions: Dimensiones del espacio 3D (x, y, z).
            device: Dispositivo de PyTorch para cálculos tensoriales.
        """
        logger.info(f"Inicializando NebulaSpace en {device} con dimensiones {dimensions}")
        self.dimensions = torch.tensor(dimensions, dtype=torch.float32, device=device)
        self.device = device
        
        # Diccionarios para búsqueda eficiente por ID
        self.neurons: Dict[int, QuantumNeuron] = {}
        self.clusters: Dict[str, Cluster] = {}
        self.sectors: Dict[str, Sector] = {}
        
        # Contadores para generación de IDs
        self.next_neuron_id = 0
        self.next_cluster_id = 0
        self.next_sector_id = 0
        
        # Estructura para búsqueda espacial eficiente
        self.kdtree = None
        self.kdtree_needs_update = True
        
        # Grafo de conexiones entre neuronas
        self.connection_graph = nx.Graph()
    
    def _get_new_id(self, type_name: str) -> Union[int, str]:
        """
        Genera un ID único para neuronas, clusters o sectores.
        
        Args:
            type_name: Tipo de entidad ('neuron', 'cluster', o 'sector').
            
        Returns:
            ID único para la entidad.
            
        Raises:
            ValueError: Si el tipo de entidad es desconocido.
        """
        if type_name == "neuron":
            self.next_neuron_id += 1
            return self.next_neuron_id - 1
        elif type_name == "cluster":
            self.next_cluster_id += 1
            return f"C{self.next_cluster_id - 1}"
        elif type_name == "sector":
            self.next_sector_id += 1
            return f"S{self.next_sector_id - 1}"
        else:
            raise ValueError(f"Tipo de ID desconocido: {type_name}")
    
    def add_neuron(self, neuron: QuantumNeuron, assign_structure: bool = True):
        """
        Añade una neurona al espacio.
        
        Args:
            neuron: Neurona a añadir.
            assign_structure: Si es True, asigna la neurona a un cluster/sector.
        """
        if neuron.id in self.neurons:
            logger.warning(f"Neurona {neuron.id} ya existe. Omitiendo adición.")
            return
        
        if not isinstance(neuron, QuantumNeuron):
            logger.error(f"Se intentó añadir un objeto que no es QuantumNeuron con ID {neuron.id}")
            return
        
        self.neurons[neuron.id] = neuron
        self.connection_graph.add_node(neuron.id)
        self.kdtree_needs_update = True
        
        if assign_structure:
            self._assign_neuron_to_structure(neuron)
    
    def remove_neuron(self, neuron_id: int):
        """
        Elimina una neurona del espacio y limpia referencias.
        
        Args:
            neuron_id: ID de la neurona a eliminar.
        """
        if neuron_id not in self.neurons:
            logger.warning(f"Neurona {neuron_id} no encontrada para eliminación.")
            return
        
        neuron = self.neurons.pop(neuron_id)
        logger.debug(f"Eliminando neurona {neuron_id}")
        
        # Eliminar del grafo
        if self.connection_graph.has_node(neuron_id):
            edges_to_remove = list(self.connection_graph.edges(neuron_id))
            self.connection_graph.remove_edges_from(edges_to_remove)
            self.connection_graph.remove_node(neuron_id)
        
        # Actualizar listas de conexiones de otras neuronas
        for other_neuron in self.neurons.values():
            other_neuron.connections = [(target_id, strength) for target_id, strength 
                                       in other_neuron.connections if target_id != neuron_id]
        
        # Eliminar del Cluster
        if neuron.cluster_id and neuron.cluster_id in self.clusters:
            cluster = self.clusters[neuron.cluster_id]
            cluster.remove_neuron(neuron)
            if not cluster.neuron_ids:  # Si el cluster queda vacío
                self._remove_empty_cluster(cluster.id)
        
        # Limpiar referencia al sector
        neuron.sector_id = None
        
        self.kdtree_needs_update = True
    
    def _remove_empty_cluster(self, cluster_id: str):
        """
        Elimina un cluster vacío y potencialmente su sector padre si queda vacío.
        
        Args:
            cluster_id: ID del cluster a eliminar.
        """
        if cluster_id not in self.clusters:
            return
        
        cluster = self.clusters.pop(cluster_id)
        logger.info(f"Eliminando cluster vacío {cluster_id}")
        
        # Encontrar el sector que contiene este cluster y eliminar referencia
        found_sector = None
        for sector in self.sectors.values():
            if cluster_id in sector.cluster_ids:
                sector.remove_cluster(cluster)
                found_sector = sector
                break
        
        if found_sector and not found_sector.cluster_ids:
            self._remove_empty_sector(found_sector.id)
    
    def _remove_empty_sector(self, sector_id: str):
        """
        Elimina un sector vacío.
        
        Args:
            sector_id: ID del sector a eliminar.
        """
        if sector_id in self.sectors:
            del self.sectors[sector_id]
            logger.info(f"Eliminando sector vacío {sector_id}")
    
    def _assign_neuron_to_structure(self, neuron: QuantumNeuron):
        """
        Asigna una neurona al cluster/sector más cercano, creando nuevos si es necesario.
        
        Args:
            neuron: Neurona a asignar.
        """
        if not self.sectors:  # Crear primer sector si no existe ninguno
            sector_id = self._get_new_id("sector")
            # Colocar sector cerca de la neurona
            sector_pos = neuron.position.data + (torch.rand_like(neuron.position.data) - 0.5) * 10
            sector = Sector(sector_id, sector_pos.clamp(0, self.dimensions - 1), self.device)
            self.sectors[sector_id] = sector
            
            # Crear primer cluster en este sector
            cluster_id = self._get_new_id("cluster")
            cluster_pos = neuron.position.data + (torch.rand_like(neuron.position.data) - 0.5) * 5
            cluster = Cluster(cluster_id, cluster_pos.clamp(0, self.dimensions - 1), self.device)
            self.clusters[cluster_id] = cluster
            
            # Añadir cluster al sector
            sector.add_cluster(cluster)
            
            # Añadir neurona al cluster
            cluster.add_neuron(neuron)
            neuron.sector_id = sector_id
            
            return
        
        # Si ya existen clusters, encontrar el más cercano
        if self.clusters:
            # Calcular distancias a todos los clusters
            cluster_positions = torch.stack([c.position for c in self.clusters.values()])
            distances = torch.norm(cluster_positions - neuron.position.data, dim=1)
            
            # Encontrar el cluster más cercano
            min_idx = torch.argmin(distances)
            closest_cluster_id = list(self.clusters.keys())[min_idx.item()]
            closest_cluster = self.clusters[closest_cluster_id]
            
            # Si la distancia es razonable, asignar a ese cluster
            if distances[min_idx] < 20.0:  # Umbral de distancia ajustable
                closest_cluster.add_neuron(neuron)
                # Asignar al sector del cluster
                for sector in self.sectors.values():
                    if closest_cluster.id in sector.cluster_ids:
                        neuron.sector_id = sector.id
                        break
                return
        
        # Si no hay clusters cercanos, crear uno nuevo en el sector más cercano
        sector_positions = torch.stack([s.position for s in self.sectors.values()])
        distances = torch.norm(sector_positions - neuron.position.data, dim=1)
        min_idx = torch.argmin(distances)
        closest_sector_id = list(self.sectors.keys())[min_idx.item()]
        closest_sector = self.sectors[closest_sector_id]
        
        # Crear nuevo cluster
        cluster_id = self._get_new_id("cluster")
        cluster_pos = neuron.position.data + (torch.rand_like(neuron.position.data) - 0.5) * 3
        cluster = Cluster(cluster_id, cluster_pos.clamp(0, self.dimensions - 1), self.device)
        self.clusters[cluster_id] = cluster
        
        # Añadir cluster al sector
        closest_sector.add_cluster(cluster)
        
        # Añadir neurona al cluster
        cluster.add_neuron(neuron)
        neuron.sector_id = closest_sector_id
    
    def initialize_neurons(self, num_neurons: int):
        """
        Inicializa un número específico de neuronas en el espacio.
        
        Args:
            num_neurons: Número de neuronas a crear.
        """
        logger.info(f"Inicializando {num_neurons} neuronas en el espacio...")
        
        added_count = 0
        for _ in range(num_neurons):
            try:
                # Generar posición aleatoria dentro de las dimensiones del espacio
                position = torch.rand(3, device=self.device) * self.dimensions
                
                # Crear neurona con ID único
                neuron_id = self._get_new_id("neuron")
                neuron = QuantumNeuron(
                    neuron_id=neuron_id,
                    position=position,
                    input_dim=PARAMETERS["INPUT_DIM"],
                    num_qubits=PARAMETERS["NUM_QUBITS"],
                    num_layers=PARAMETERS["QUANTUM_LAYERS"],
                    device=self.device
                )
                
                # Añadir neurona al espacio sin asignar estructura todavía
                self.add_neuron(neuron, assign_structure=False)
                added_count += 1
            except Exception as e:
                logger.error(f"Error al inicializar neurona {neuron_id}: {e}")
                # Revertir contador de ID si falla la inicialización
                self.next_neuron_id -= 1
        
        logger.info(f"Añadidas con éxito {added_count}/{num_neurons} neuronas.")
        
        # Asignar estructura después de añadir todas las neuronas
        logger.info("Asignando estructura inicial...")
        if self.neurons:
            # La asignación inicial puede ser simple o usar update_structure
            self.update_structure()  # Usar K-Means para estructura inicial
        
        self.kdtree_needs_update = True
    
    def _update_kdtree(self):
        """Actualiza el KDTree para búsqueda espacial eficiente."""
        if not self.neurons:
            self.kdtree = None
            return
        
        positions = np.array([convert_to_numpy(n.position.data) for n in self.neurons.values()])
        ids = list(self.neurons.keys())
        
        self.kdtree = cKDTree(positions)
        self.kdtree_data = {
            'positions': positions,
            'ids': ids
        }
        self.kdtree_needs_update = False
    
    def find_neurons_within_radius(self, position: torch.Tensor, radius: float) -> List[QuantumNeuron]:
        """
        Encuentra neuronas dentro de un radio específico de una posición.
        
        Args:
            position: Posición central para la búsqueda.
            radius: Radio de búsqueda.
            
        Returns:
            Lista de neuronas dentro del radio.
        """
        if self.kdtree_needs_update:
            self._update_kdtree()
        
        if self.kdtree is None:
            return []
        
        pos_np = convert_to_numpy(position)
        indices = self.kdtree.query_ball_point(pos_np, radius)
        
        if not indices:
            return []
        
        # Convertir índices a IDs de neurona y luego a objetos neurona
        neuron_ids = [self.kdtree_data['ids'][i] for i in indices]
        return [self.neurons[nid] for nid in neuron_ids if nid in self.neurons]
    
    def calculate_light_intensity(self, emitter: QuantumNeuron, receiver_position: torch.Tensor) -> float:
        """
        Calcula la intensidad de luz que llega de un emisor a una posición receptora.
        
        Args:
            emitter: Neurona emisora.
            receiver_position: Posición del receptor.
            
        Returns:
            Intensidad de luz en la posición receptora.
        """
        # Modelo simple: intensidad disminuye con el cuadrado de la distancia
        distance_sq = torch.sum((emitter.position.data - receiver_position) ** 2).item()
        base_intensity = emitter.emit_light()
        
        # Evitar división por cero
        if distance_sq < 0.0001:
            distance_sq = 0.0001
        
        # Factor de atenuación
        attenuation_factor = PARAMETERS.get("LIGHT_ATTENUATION_FACTOR", 0.3)
        
        # Intensidad = luminosidad / (distancia^2 * factor)
        intensity = base_intensity / (distance_sq * attenuation_factor)
        
        # Limitar intensidad máxima
        return min(intensity, 1.0)
    
    def run_simulation_step(self, iteration: int):
        """
        Ejecuta un paso de simulación en el espacio de NEBULA.
        
        Args:
            iteration: Número de iteración actual.
        """
        start_time = time.time()
        logger.debug(f"Ejecutando paso de simulación {iteration}...")
        
        # 1. Propagación de Luz
        self._propagate_light_step()
        
        # 2. Actualización de Conexiones
        self._update_connections_step()
        
        # 3. Actualización de Posiciones
        self._update_positions_step()
        
        # 4. Decaimiento de Luminosidad y Poda de Neuronas Inactivas
        self._decay_and_prune_step(iteration)
        
        # 5. Actualización de Estructura (menos frecuente)
        if iteration % PARAMETERS.get("STRUCTURE_UPDATE_INTERVAL", 25) == 0:
            self.update_structure()
        
        # Marcar KDTree para actualización
        self.kdtree_needs_update = True
        
        elapsed = time.time() - start_time
        logger.debug(f"Paso de simulación {iteration} completado en {elapsed:.4f} segundos")
    
    def _propagate_light_step(self):
        """Calcula y aplica la intensidad de luz recibida por cada neurona."""
        num_neurons = len(self.neurons)
        if num_neurons < 2:
            return
        
        # Almacenar intensidades para aplicar actualizaciones simultáneamente
        received_intensities = defaultdict(float)
        all_neurons_list = list(self.neurons.values())
        
        # Iteración N^2 simple (puede optimizarse con KDTree para interacciones dispersas)
        for i in range(num_neurons):
            emitter = all_neurons_list[i]
            for j in range(num_neurons):
                if i == j:
                    continue  # La neurona no se ilumina a sí misma
                
                receiver = all_neurons_list[j]
                intensity = self.calculate_light_intensity(emitter, receiver.position.data)
                received_intensities[receiver.id] += intensity
        
        # Aplicar actualizaciones basadas en intensidades acumuladas
        for neuron_id, total_intensity in received_intensities.items():
            if neuron_id in self.neurons:
                self.neurons[neuron_id].receive_light(total_intensity)
    
    def _update_connections_step(self):
        """Actualiza conexiones entre neuronas (en lista interna y grafo)."""
        max_connections = PARAMETERS.get("MAX_CONNECTIONS", 10)
        connection_prob = PARAMETERS.get("CONNECTION_PROBABILITY", 0.08)
        connection_radius = 30  # Distancia máxima para conexiones potenciales
        weak_connection_threshold = 0.05  # Umbral para podar conexiones débiles
        
        edges_to_add = []
        edges_to_remove = []
        edges_to_update = {}  # Almacenar {(u,v): nuevo_peso}
        
        for neuron1_id, neuron1 in self.neurons.items():
            # Podar conexiones débiles o inválidas
            current_connections_map = {target_id: strength for target_id, strength in neuron1.connections}
            valid_targets_in_list = set(current_connections_map.keys())
            connections_to_keep = []
            
            for target_id, strength in neuron1.connections:
                if target_id not in self.neurons:  # Objetivo eliminado
                    edges_to_remove.append(tuple(sorted((neuron1_id, target_id))))
                    valid_targets_in_list.remove(target_id)
                    continue
                
                # Ejemplo de decaimiento
                new_strength = strength * 0.99
                if new_strength < weak_connection_threshold:
                    edges_to_remove.append(tuple(sorted((neuron1_id, target_id))))
                    valid_targets_in_list.remove(target_id)
                else:
                    connections_to_keep.append((target_id, new_strength))
                    edges_to_update[tuple(sorted((neuron1_id, target_id)))] = new_strength
            
            neuron1.connections = connections_to_keep
            num_current_connections = len(neuron1.connections)
            
            # Añadir nuevas conexiones
            if num_current_connections < max_connections:
                # Encontrar vecinos potenciales dentro del radio
                potential_neighbors = self.find_neurons_within_radius(
                    neuron1.position.data, connection_radius
                )
                
                # Filtrar auto-conexiones y neuronas ya conectadas
                eligible_targets = [
                    n for n in potential_neighbors
                    if n.id != neuron1_id and n.id not in valid_targets_in_list
                ]
                
                # Añadir nuevas conexiones probabilísticamente
                added_count = 0
                random.shuffle(eligible_targets)  # Evitar sesgo hacia neuronas más cercanas
                
                for target_neuron in eligible_targets:
                    if num_current_connections + added_count >= max_connections:
                        break
                    
                    if random.random() < connection_prob:
                        # Calcular fuerza inicial (basada en distancia inversa)
                        dist = torch.norm(neuron1.position.data - target_neuron.position.data).item()
                        strength = max(0.1, (connection_radius - dist) / connection_radius)
                        strength = round(strength, 3)  # Mantener precisión razonable
                        
                        neuron1.connections.append((target_neuron.id, strength))
                        edges_to_add.append((neuron1_id, target_neuron.id, {"weight": strength}))
                        added_count += 1
        
        # Actualizar el grafo NetworkX por lotes
        unique_edges_to_remove = set(edges_to_remove)
        self.connection_graph.remove_edges_from(list(unique_edges_to_remove))
        self.connection_graph.add_edges_from(edges_to_add)
        
        for (u, v), weight in edges_to_update.items():
            # Asegurar que el borde aún existe después de eliminaciones
            if self.connection_graph.has_edge(u, v):
                self.connection_graph[u][v]['weight'] = weight
    
    def _update_positions_step(self):
        """Actualiza posiciones de neuronas basándose en el modelo de interacción."""
        model = PARAMETERS.get("NEURON_INTERACTION_MODEL", "none")
        if model == "none" or not self.neurons:
            return
        
        forces = {nid: torch.zeros(3, device=self.device) for nid in self.neurons}
        # Obtener lista fija para iteración
        current_positions = {nid: n.position.data.clone() for nid, n in self.neurons.items()}
        neuron_list = list(self.neurons.values())
        
        if model == "light_attenuation":
            attraction_factor = 0.01  # Atrae si interactúan fuertemente
            repulsion_factor = 0.03   # Repele en caso contrario
            intensity_threshold = 0.2  # Umbral para cambiar entre atracción/repulsión
            
            for i in range(len(neuron_list)):
                neuron1 = neuron_list[i]
                pos1 = current_positions[neuron1.id]
                
                for j in range(i + 1, len(neuron_list)):
                    neuron2 = neuron_list[j]
                    pos2 = current_positions[neuron2.id]
                    
                    direction = pos2 - pos1
                    distance_sq = torch.sum(direction**2)
                    distance = torch.sqrt(distance_sq + 1e-6)  # Evitar división por cero
                    
                    # Calcular intensidad mutua (simplificación)
                    intensity1 = self.calculate_light_intensity(neuron1, pos2)
                    intensity2 = self.calculate_light_intensity(neuron2, pos1)
                    mutual_intensity = (intensity1 + intensity2) / 2.0
                    
                    if mutual_intensity > intensity_threshold:
                        # Fuerza de atracción proporcional a intensidad y distancia
                        force_magnitude = attraction_factor * mutual_intensity * distance
                    else:
                        # Fuerza de repulsión inversamente proporcional al cuadrado de la distancia
                        force_magnitude = -repulsion_factor / distance_sq
                    
                    force_vector = force_magnitude * (direction / distance)
                    
                    # Limitar magnitud de fuerza para prevenir velocidades extremas
                    force_vector = torch.clamp(force_vector, -0.5, 0.5)
                    
                    forces[neuron1.id] += force_vector
                    forces[neuron2.id] -= force_vector  # Tercera ley de Newton
        
        # Aplicar fuerzas y actualizar posiciones
        dt = PARAMETERS.get("POSITION_UPDATE_DT", 0.1)
        max_displacement_per_step = 0.5  # Limitar velocidad de movimiento
        
        positions_changed = False
        for neuron_id, force in forces.items():
            if neuron_id in self.neurons:
                neuron = self.neurons[neuron_id]
                # Integración simple de Euler: velocidad = fuerza * dt (masa=1)
                velocity = force * dt
                
                # Limitar velocidad
                velocity_norm = torch.norm(velocity)
                if velocity_norm > max_displacement_per_step:
                    velocity = velocity * (max_displacement_per_step / velocity_norm)
                
                if torch.any(torch.abs(velocity) > 1e-4):  # Solo actualizar si el movimiento es significativo
                    # Actualizar posición in-place
                    neuron.position.data += velocity
                    # Mantener neuronas dentro de límites (rebote o clamp) - Clamp simple:
                    neuron.position.data.clamp_(
                        min=torch.zeros(3, device=self.device), 
                        max=self.dimensions - 1
                    )
                    positions_changed = True
        
        if positions_changed:
            self.kdtree_needs_update = True
    
    def _decay_and_prune_step(self, iteration: int):
        """Decae luminosidad y elimina neuronas inactivas."""
        inactive_threshold = PARAMETERS.get("NEURON_ACTIVITY_THRESHOLD", 0.1)
        neurons_to_prune = []
        
        # Verificar solo periódicamente para ahorrar cómputo
        if iteration % 20 != 0:  # Verificar cada 20 iteraciones
            # Aún decaer luminosidad en cada paso
            for neuron in self.neurons.values():
                neuron.decay_luminosity()
            return
        
        logger.debug("Realizando verificación periódica de poda...")
        for neuron_id, neuron in self.neurons.items():
            neuron.decay_luminosity()
            
            # Podar si la luminosidad es muy baja durante un tiempo
            if neuron.luminosity.item() < inactive_threshold:
                neurons_to_prune.append(neuron_id)
        
        if neurons_to_prune and len(self.neurons) > PARAMETERS.get("MIN_NEURONS", 50):
            num_to_prune = min(len(neurons_to_prune), len(self.neurons) - PARAMETERS.get("MIN_NEURONS", 50))
            
            # Podar las de menor luminosidad entre las candidatas
            candidates = {nid: self.neurons[nid].luminosity.item() for nid in neurons_to_prune}
            sorted_candidates = sorted(candidates.items(), key=lambda item: item[1])
            ids_to_remove = [nid for nid, lum in sorted_candidates[:num_to_prune]]
            
            if ids_to_remove:
                logger.info(f"Podando {len(ids_to_remove)} neuronas inactivas (luminosidad < {inactive_threshold:.2f}).")
                for neuron_id in ids_to_remove:
                    self.remove_neuron(neuron_id)
    
    def update_structure(self):
        """Actualiza clusters/sectores basándose en posiciones de neuronas usando K-Means."""
        num_neurons = len(self.neurons)
        if num_neurons < PARAMETERS["N_CLUSTERS"]:
            logger.warning(f"No hay suficientes neuronas ({num_neurons}) para clustering K-Means. Omitiendo actualización de estructura.")
            return
        
        logger.info(f"Actualizando estructura de Nebula (Clustering {num_neurons} neuronas)...")
        start_time = time.time()
        
        try:
            # 1. Obtener Embeddings (posición, luminosidad, etc.)
            neuron_ids = list(self.neurons.keys())
            embeddings = np.array([self.neurons[nid].get_embedding() for nid in neuron_ids])
            
            if embeddings.shape[0] != num_neurons:
                logger.error("Discrepancia entre conteo de neuronas y embeddings.")
                return
            
            # Verificar NaNs/Infs en embeddings
            if np.any(np.isnan(embeddings)) or np.any(np.isinf(embeddings)):
                logger.error("¡Detectado NaN o Inf en embeddings de neuronas! No se puede realizar clustering.")
                return
            
            # Normalizar embeddings
            scaler = MinMaxScaler()
            embeddings_scaled = scaler.fit_transform(embeddings)
            
            # 2. Realizar Clustering K-Means
            n_clusters = min(PARAMETERS["N_CLUSTERS"], num_neurons)
            kmeans = KMeans(n_clusters=n_clusters, random_state=PARAMETERS["SEED"], n_init=10)
            labels = kmeans.fit_predict(embeddings_scaled)
            
            # 3. Reasignar neuronas a NUEVOS clusters y sectores
            # Limpiar enlaces de estructura antiguos primero
            for neuron in self.neurons.values():
                neuron.cluster_id = None
                neuron.sector_id = None
            
            old_clusters = self.clusters
            old_sectors = self.sectors
            self.clusters = {}
            self.sectors = {}
            
            for sector in old_sectors.values():
                sector.cluster_ids.clear()
            
            # Crear nuevos clusters basados en resultados de K-Means
            new_clusters_temp = defaultdict(list)  # Almacén temporal {etiqueta: [neuron_id]}
            for i, neuron_id in enumerate(neuron_ids):
                new_clusters_temp[labels[i]].append(neuron_id)
            
            # Crear objetos Cluster y asignar neuronas
            for label, members in new_clusters_temp.items():
                if not members:
                    continue
                
                cluster_id = self._get_new_id("cluster")
                
                # Calcular centro del cluster (usar posición promedio de miembros)
                member_positions = [self.neurons[nid].position.data for nid in members]
                cluster_center = torch.mean(torch.stack(member_positions), dim=0)
                
                cluster = Cluster(cluster_id, cluster_center, self.device)
                self.clusters[cluster_id] = cluster
                
                for nid in members:
                    cluster.add_neuron(self.neurons[nid])
            
            # 4. Asignar Clusters a Sectores
            # Enfoque simple: crear nuevos sectores basados en proximidad de clusters
            if self.clusters:
                # Usar K-Means nuevamente para agrupar clusters en sectores
                n_sectors = min(3, len(self.clusters))  # Número de sectores ajustable
                
                cluster_positions = np.array([convert_to_numpy(c.position) for c in self.clusters.values()])
                cluster_ids = list(self.clusters.keys())
                
                # Verificar NaNs/Infs
                if np.any(np.isnan(cluster_positions)) or np.any(np.isinf(cluster_positions)):
                    logger.error("¡Detectado NaN o Inf en posiciones de clusters! Usando asignación simple.")
                    # Fallback: crear un solo sector
                    sector_id = self._get_new_id("sector")
                    sector_pos = torch.mean(torch.stack([c.position for c in self.clusters.values()]), dim=0)
                    sector = Sector(sector_id, sector_pos, self.device)
                    self.sectors[sector_id] = sector
                    
                    # Asignar todos los clusters a este sector
                    for cluster in self.clusters.values():
                        sector.add_cluster(cluster)
                        # Asignar sector_id a todas las neuronas en este cluster
                        for nid in cluster.neuron_ids:
                            if nid in self.neurons:
                                self.neurons[nid].sector_id = sector_id
                else:
                    # Usar K-Means para agrupar clusters en sectores
                    sector_kmeans = KMeans(n_clusters=n_sectors, random_state=PARAMETERS["SEED"], n_init=10)
                    sector_labels = sector_kmeans.fit_predict(cluster_positions)
                    
                    # Crear sectores y asignar clusters
                    sector_centers = sector_kmeans.cluster_centers_
                    for i in range(n_sectors):
                        sector_id = self._get_new_id("sector")
                        sector_pos = torch.tensor(sector_centers[i], dtype=torch.float32, device=self.device)
                        sector = Sector(sector_id, sector_pos, self.device)
                        self.sectors[sector_id] = sector
                        
                        # Asignar clusters a este sector
                        for j, cluster_id in enumerate(cluster_ids):
                            if sector_labels[j] == i:
                                cluster = self.clusters[cluster_id]
                                sector.add_cluster(cluster)
                                
                                # Asignar sector_id a todas las neuronas en este cluster
                                for nid in cluster.neuron_ids:
                                    if nid in self.neurons:
                                        self.neurons[nid].sector_id = sector_id
            
            elapsed = time.time() - start_time
            logger.info(f"Actualización de estructura completada en {elapsed:.2f}s. Clusters: {len(self.clusters)}, Sectores: {len(self.sectors)}")
            
        except Exception as e:
            logger.error(f"Error durante actualización de estructura: {e}", exc_info=True)
    
    def get_space_state(self) -> Dict[str, Any]:
        """
        Devuelve el estado serializable del espacio completo.
        
        Returns:
            Diccionario con el estado del espacio.
        """
        # Guardar neuronas
        neurons_state = {}
        for nid, neuron in self.neurons.items():
            neurons_state[nid] = neuron.get_state()
        
        # Guardar clusters
        clusters_state = {}
        for cid, cluster in self.clusters.items():
            clusters_state[cid] = cluster.get_state()
        
        # Guardar sectores
        sectors_state = {}
        for sid, sector in self.sectors.items():
            sectors_state[sid] = sector.get_state()
        
        # Guardar grafo de conexiones (convertir a formato serializable)
        graph_data = {
            'nodes': list(self.connection_graph.nodes()),
            'edges': [(u, v, d) for u, v, d in self.connection_graph.edges(data=True)]
        }
        
        state = {
            'neurons': neurons_state,
            'clusters': clusters_state,
            'sectors': sectors_state,
            'graph': graph_data,
            'next_neuron_id': self.next_neuron_id,
            'next_cluster_id': self.next_cluster_id,
            'next_sector_id': self.next_sector_id,
            'dimensions': convert_to_numpy(self.dimensions)
        }
        
        return state
    
    def load_space_state(self, state: Dict[str, Any]):
        """
        Carga el estado del espacio desde un estado guardado.
        
        Args:
            state: Estado guardado del espacio.
        """
        if not state:
            logger.warning("Estado vacío proporcionado para carga. Omitiendo.")
            return
        
        # Limpiar estado actual
        self.neurons = {}
        self.clusters = {}
        self.sectors = {}
        self.connection_graph = nx.Graph()
        
        # Cargar dimensiones
        if 'dimensions' in state:
            self.dimensions = torch.tensor(state['dimensions'], dtype=torch.float32, device=self.device)
        
        # Cargar contadores de ID
        self.next_neuron_id = state.get('next_neuron_id', 0)
        self.next_cluster_id = state.get('next_cluster_id', 0)
        self.next_sector_id = state.get('next_sector_id', 0)
        
        # Cargar neuronas
        neurons_state = state.get('neurons', {})
        for nid, neuron_state in neurons_state.items():
            try:
                neuron = QuantumNeuron.from_state(neuron_state, self.device)
                self.neurons[neuron.id] = neuron
                self.connection_graph.add_node(neuron.id)
            except Exception as e:
                logger.error(f"Error al cargar neurona {nid}: {e}")
        
        # Cargar clusters
        clusters_state = state.get('clusters', {})
        for cid, cluster_state in clusters_state.items():
            try:
                cluster = Cluster.from_state(cluster_state, self.device)
                self.clusters[cluster.id] = cluster
            except Exception as e:
                logger.error(f"Error al cargar cluster {cid}: {e}")
        
        # Cargar sectores
        sectors_state = state.get('sectors', {})
        for sid, sector_state in sectors_state.items():
            try:
                sector = Sector.from_state(sector_state, self.device)
                self.sectors[sector.id] = sector
            except Exception as e:
                logger.error(f"Error al cargar sector {sid}: {e}")
        
        # Cargar grafo de conexiones
        graph_data = state.get('graph', {'nodes': [], 'edges': []})
        
        # Añadir nodos (ya añadidos al crear neuronas)
        # Añadir bordes
        for u, v, d in graph_data.get('edges', []):
            if u in self.neurons and v in self.neurons:
                self.connection_graph.add_edge(u, v, **d)
        
        # Reconstruir conexiones internas de neuronas desde el grafo
        for neuron_id, neuron in self.neurons.items():
            neuron.connections = []
            if self.connection_graph.has_node(neuron_id):
                for neighbor in self.connection_graph.neighbors(neuron_id):
                    if self.connection_graph.has_edge(neuron_id, neighbor):
                        weight = self.connection_graph[neuron_id][neighbor].get('weight', 0.5)
                        neuron.connections.append((neighbor, weight))
        
        self.kdtree_needs_update = True
        logger.info(f"Estado del espacio cargado: {len(self.neurons)} neuronas, {len(self.clusters)} clusters, {len(self.sectors)} sectores")
