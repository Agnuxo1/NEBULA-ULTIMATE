"""
Implementación de la clase principal NebulaAGI para NEBULA.

Esta clase integra todos los componentes del sistema NEBULA y gestiona
el ciclo de aprendizaje continuo, evolución y automejora.
"""

import logging
import time
import sys
import gc
import os
import pickle
import shutil
import inspect
import traceback
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union, Callable
from collections import deque

import numpy as np
import torch
import torch.nn as nn

from core.nebula_space import NebulaSpace
from utils.config import PARAMETERS
from utils.helpers import convert_to_numpy, safe_loop, require_llm

logger = logging.getLogger("NEBULA.NebulaAGI")

class NebulaAGI:
    """
    Clase principal que integra todos los componentes del sistema NEBULA.
    
    NebulaAGI coordina el funcionamiento de todos los subsistemas:
    - Entorno espacial (NebulaSpace)
    - Sistema de conocimiento (EnhancedKnowledgeGraph, HolographicMemory)
    - Procesamiento de lenguaje (LLMs)
    - Evolución (NebulaGenome, algoritmos genéticos)
    - Automejora (detección y corrección de errores)
    """
    
    VERSION = "1.0"
    
    def __init__(self):
        """Inicializa el sistema NEBULA."""
        self._print_banner()
        self.initialized = False
        self.start_time = time.time()
        self.iteration = 0
        self.last_backup_time = 0
        self.last_evolution_time = 0
        self.last_improvement_check_time = 0
        self.last_structure_update_time = 0
        self.shutdown_requested = False
        
        # Historiales y monitoreo
        self.error_history = deque(maxlen=PARAMETERS["MAX_ERROR_HISTORY"])
        self.modification_history = deque(maxlen=PARAMETERS["MAX_MODIFICATION_HISTORY"])
        self.performance_history = deque(maxlen=200)
        self.llm_interaction_log = deque(maxlen=100)
        
        # Componentes principales (inicializar con placeholders)
        self.device = PARAMETERS["DEVICE"]
        self.space: Optional[NebulaSpace] = None
        self.knowledge_graph = None
        self.holographic_memory = None
        self.optical_processor = None
        self.genome = None
        self.genetic_algorithm = None
        self.error_correction_system = None
        self.llm_manager = None
        
        # Herramientas NLP
        self.spacy_nlp = None
        self._load_nlp_tools()
        
        # Gestión de LLMs
        self.llm_models = {}
        self.llm_load_status = {}
        self._init_llm_placeholders()
        
        # Secuencia de inicialización de componentes
        init_steps = [
            ("NebulaSpace", self._init_neural_space),
            ("Knowledge Systems", self._init_knowledge_systems),
            ("Evolution Engine", self._init_evolution_engine),
            ("Processing Units", self._init_processing_units),
            ("Analysis Tools", self._init_analysis_tools),
            ("Error Correction", self._init_error_correction),
        ]
        
        initialization_successful = True
        for name, init_func in init_steps:
            logger.info(f"Inicializando: {name}...")
            try:
                if not init_func():
                    logger.error(f"❌ Error al inicializar {name}. El sistema puede ser inestable.")
            except Exception as e:
                logger.critical(f"💥 ERROR CRÍTICO durante inicialización de {name}: {e}", exc_info=True)
                initialization_successful = False
                break
        
        if not initialization_successful:
            logger.critical("Inicialización de NEBULA falló. Saliendo.")
            sys.exit(1)
        
        # Cargar estado previo DESPUÉS de inicializar componentes
        self.load_state()
        
        # Aplicar el genoma actual a los parámetros después de cargar el estado
        if self.genome:
            self.genome.apply_to_parameters()
        
        self.initialized = True
        logger.info("✅ Inicialización de NEBULA completada.")
        self.display_statistics()
    
    def _print_banner(self):
        """Imprime un banner de inicio."""
        print("*" * 70)
        print(f"🚀 Inicializando NEBULA v{self.VERSION} - Sistema de IA Autónomo 🚀")
        print("*" * 70)
        print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Python: {sys.version.split()[0]}")
        print(f"PyTorch: {torch.__version__}")
        try:
            import pennylane as qml
            print(f"PennyLane: {qml.__version__}")
        except ImportError:
            print("PennyLane: No disponible")
        try:
            import transformers
            print(f"Transformers: {transformers.__version__}")
        except ImportError:
            print("Transformers: No disponible")
        try:
            import deap
            print(f"DEAP: {deap.__version__}")
        except ImportError:
            print("DEAP: No disponible")
        print("-" * 70)
    
    def _load_nlp_tools(self):
        """Carga el modelo de spaCy para NLP."""
        try:
            import spacy
            logger.info("Cargando modelo de spaCy (en_core_web_sm)...")
            try:
                self.spacy_nlp = spacy.load("en_core_web_sm")
                logger.info("Modelo de spaCy cargado.")
            except OSError:
                logger.warning("Modelo 'en_core_web_sm' de spaCy no encontrado. Intentando descarga...")
                spacy.cli.download("en_core_web_sm")
                self.spacy_nlp = spacy.load("en_core_web_sm")
                logger.info("Modelo de spaCy descargado y cargado.")
        except ImportError:
            logger.warning("spaCy no disponible. Características de NLP limitadas.")
    
    def _init_llm_placeholders(self):
        """Inicializa placeholders para modelos LLM."""
        try:
            # Verificar si transformers está disponible
            import transformers
            import sentence_transformers
            
            # Configurar placeholders para modelos
            self.llm_models = {
                "embedding": {
                    "config_key": "EMBEDDING_MODEL_NAME",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                },
                "text_generation_small": {
                    "config_key": "GENERATION_MODEL_SMALL",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                },
                "text_generation_large": {
                    "config_key": "GENERATION_MODEL_LARGE",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                },
                "code_generation": {
                    "config_key": "CODEGEN_MODEL_NAME",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                },
                "qa": {
                    "config_key": "QA_MODEL_NAME",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                },
                "image_captioning": {
                    "config_key": "IMAGE_CAPTION_MODEL_NAME",
                    "model": None,
                    "tokenizer": None,
                    "processor": None,
                    "pipeline": None,
                    "last_used": 0
                }
            }
            
            # Inicializar estado de carga
            self.llm_load_status = {key: False for key in self.llm_models.keys()}
            logger.info("Placeholders de LLM inicializados.")
        except ImportError:
            logger.warning("Transformers no disponible. Características de LLM deshabilitadas.")
    
    def _init_neural_space(self) -> bool:
        """Inicializa el espacio neural (NebulaSpace)."""
        try:
            logger.info("Inicializando NebulaSpace...")
            self.space = NebulaSpace(
                dimensions=PARAMETERS["SPACE_DIMENSIONS"],
                device=self.device
            )
            
            # Inicializar neuronas
            self.space.initialize_neurons(PARAMETERS["INITIAL_NEURONS"])
            
            logger.info(f"NebulaSpace inicializado con {len(self.space.neurons)} neuronas.")
            return True
        except Exception as e:
            logger.error(f"Error al inicializar NebulaSpace: {e}", exc_info=True)
            return False
    
    def _init_knowledge_systems(self) -> bool:
        """Inicializa los sistemas de conocimiento (KnowledgeGraph, HolographicMemory)."""
        # Placeholder - Implementar cuando se desarrollen los módulos de conocimiento
        logger.info("Sistemas de conocimiento: implementación pendiente.")
        return True
    
    def _init_evolution_engine(self) -> bool:
        """Inicializa el motor de evolución (NebulaGenome, algoritmos genéticos)."""
        # Placeholder - Implementar cuando se desarrolle el módulo de evolución
        logger.info("Motor de evolución: implementación pendiente.")
        return True
    
    def _init_processing_units(self) -> bool:
        """Inicializa unidades de procesamiento (OpticalProcessingUnit)."""
        # Placeholder - Implementar cuando se desarrolle el módulo de procesamiento óptico
        logger.info("Unidades de procesamiento: implementación pendiente.")
        return True
    
    def _init_analysis_tools(self) -> bool:
        """Inicializa herramientas de análisis."""
        # Placeholder - Implementar cuando se desarrollen las herramientas de análisis
        logger.info("Herramientas de análisis: implementación pendiente.")
        return True
    
    def _init_error_correction(self) -> bool:
        """Inicializa el sistema de corrección de errores."""
        # Placeholder - Implementar cuando se desarrolle el módulo de corrección de errores
        logger.info("Sistema de corrección de errores: implementación pendiente.")
        return True
    
    def is_llm_loaded(self, model_key: str) -> bool:
        """
        Verifica si un modelo LLM está cargado.
        
        Args:
            model_key: Clave del modelo a verificar.
            
        Returns:
            True si el modelo está cargado, False en caso contrario.
        """
        if model_key not in self.llm_models:
            return False
        
        model_info = self.llm_models[model_key]
        model = model_info.get("model")
        
        # Para SentenceTransformer, solo necesitamos el modelo
        if model_key == "embedding":
            return model is not None
        
        # Para otros modelos, necesitamos modelo y tokenizer/processor
        tokenizer_or_processor = model_info.get("tokenizer") or model_info.get("processor")
        return model is not None and tokenizer_or_processor is not None
    
    def load_llm_model(self, model_key: str) -> bool:
        """
        Carga un modelo LLM específico.
        
        Args:
            model_key: Clave del modelo a cargar.
            
        Returns:
            True si el modelo se cargó correctamente, False en caso contrario.
        """
        # Placeholder - Implementar cuando se desarrolle el módulo de LLM
        logger.info(f"Carga de modelo LLM '{model_key}': implementación pendiente.")
        return False
    
    def _check_memory_usage(self, context: str = "", trigger_unload: bool = True) -> bool:
        """
        Verifica el uso de memoria y opcionalmente descarga modelos si es necesario.
        
        Args:
            context: Contexto para el registro.
            trigger_unload: Si es True, descarga modelos si la memoria está alta.
            
        Returns:
            True si la memoria está alta, False en caso contrario.
        """
        import psutil
        
        # Verificar memoria RAM
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        
        # Verificar memoria GPU si está disponible
        gpu_memory_percent = 0
        try:
            if self.device.type == 'cuda':
                import GPUtil
                gpus = GPUtil.getGPUs()
                if gpus:
                    gpu = gpus[0]  # Asumir una sola GPU por simplicidad
                    gpu_memory_percent = gpu.memoryUtil * 100
        except (ImportError, Exception):
            pass
        
        # Determinar si la memoria está alta
        high_memory = memory_percent > 85 or gpu_memory_percent > 85
        
        if high_memory:
            logger.warning(f"Alta presión de memoria {context}: RAM {memory_percent:.1f}%, GPU {gpu_memory_percent:.1f}%")
            
            if trigger_unload:
                # Descargar modelos LLM para liberar memoria
                self.unload_inactive_llms()
                
                # Forzar recolección de basura
                gc.collect()
                if self.device.type == 'cuda':
                    torch.cuda.empty_cache()
        
        return high_memory
    
    def unload_inactive_llms(self):
        """Descarga modelos LLM inactivos para liberar memoria."""
        # Placeholder - Implementar cuando se desarrolle el módulo de LLM
        logger.debug("Descarga de modelos LLM inactivos: implementación pendiente.")
    
    # --- Lógica principal y bucle de simulación ---
    
    def run(self):
        """Inicia la lógica de ejecución principal."""
        if not self.initialized:
            logger.critical("NEBULA no inicializado correctamente. No se puede ejecutar.")
            return
        
        logger.info("Ejecutando NEBULA en modo headless...")
        self.continuous_learning_loop()  # Ejecutar bucle directamente (bloqueante)
    
    @safe_loop(max_retries=5, delay=10)
    def continuous_learning_loop(self):
        """
        Bucle principal que impulsa la operación, aprendizaje y evolución de NEBULA.
        
        Este bucle se ejecuta continuamente hasta que se solicita el apagado.
        """
        if self.shutdown_requested:
            return
        
        logger.info(f"🚀 Iniciando Bucle de Aprendizaje Continuo (Iteración {self.iteration})...")
        
        while not self.shutdown_requested:
            start_iter_time = time.time()
            self.iteration += 1
            logger.info(f"--- Iteración {self.iteration} ---")
            
            try:
                # --- Paso de simulación principal ---
                if self.space:
                    self.space.run_simulation_step(self.iteration)
                
                # --- Adquisición y procesamiento de información ---
                if self.iteration % 5 == 0:  # Ciclo de aprendizaje más frecuente
                    self.acquire_and_process_information()
                
                # --- Evolución ---
                if PARAMETERS["EVOLUTION_ENABLED"] and self.iteration % PARAMETERS["EVOLUTION_INTERVAL"] == 0:
                    self.evolve_system()
                
                # --- Verificación de automejora/corrección ---
                if PARAMETERS["SELF_CORRECTION_ENABLED"] and self.iteration % PARAMETERS["SELF_IMPROVEMENT_INTERVAL"] == 0:
                    self.consider_self_improvement()
                
                # --- Monitoreo y estado ---
                if self.iteration % 20 == 0:  # Actualizar estadísticas con menos frecuencia
                    self.display_statistics()
                
                if time.time() - self.last_backup_time > PARAMETERS["BACKUP_INTERVAL"]:
                    self.save_state()
                
                # --- Gestión de recursos ---
                if self.iteration % 15 == 0:  # Verificar memoria periódicamente
                    self._check_memory_usage(f"Verificación de recursos de iteración {self.iteration}")
                    self.unload_inactive_llms()
                
                # --- Temporización de iteración ---
                iter_duration = time.time() - start_iter_time
                sleep_time = max(0.1, 1.0 - iter_duration)  # Pausa mínima de 0.1s, objetivo de ~1s por ciclo
                time.sleep(sleep_time)
                
            except Exception as loop_e:
                logger.critical(f"💥 EXCEPCIÓN NO MANEJADA EN BUCLE PRINCIPAL (Iteración {self.iteration}): {loop_e}", exc_info=True)
                
                # Intentar manejar vía sistema de errores
                try:
                    context = self.get_relevant_code_snippet(depth=1)  # Obtener contexto del nivel de bucle
                except:
                    context = "No se pudo obtener contexto de bucle."
                
                self.handle_error(loop_e, context)
                
                # Considerar añadir una pausa más larga después de errores no manejados
                time.sleep(5)
        
        logger.info("Bucle de aprendizaje continuo finalizado.")
    
    def acquire_and_process_information(self):
        """Adquiere información (ej. Wikipedia) y la procesa."""
        # Placeholder - Implementar cuando se desarrollen los módulos de adquisición de conocimiento
        logger.debug("Adquisición y procesamiento de información: implementación pendiente.")
    
    def evolve_system(self):
        """Ejecuta el ciclo de evolución para optimizar parámetros del sistema."""
        # Placeholder - Implementar cuando se desarrolle el módulo de evolución
        logger.debug("Evolución del sistema: implementación pendiente.")
    
    def consider_self_improvement(self):
        """Considera posibles mejoras al código y estructura del sistema."""
        # Placeholder - Implementar cuando se desarrolle el módulo de automejora
        logger.debug("Consideración de automejora: implementación pendiente.")
    
    # --- Gestión de errores y automejora ---
    
    def get_relevant_code_snippet(self, depth: int = 1) -> str:
        """
        Obtiene un fragmento de código relevante para el contexto de error actual.
        
        Args:
            depth: Profundidad del marco de pila a examinar.
            
        Returns:
            Fragmento de código relevante.
        """
        try:
            # Obtener marco de pila
            frame = inspect.currentframe()
            for _ in range(depth):
                if frame.f_back:
                    frame = frame.f_back
                else:
                    break
            
            filename = inspect.getfile(frame)
            lineno = frame.f_lineno
            
            if filename != __file__:
                return f"Error ocurrido fuera del script principal ({filename})"
            
            # Leer el archivo fuente
            with open(filename, 'r') as f:
                lines = f.readlines()
            
            # Extraer fragmento relevante
            start = max(0, lineno - 8)
            end = min(len(lines), lineno + 7)
            
            snippet = f"... (Líneas {start+1}-{end} de {Path(filename).name}) ...\n"
            snippet += "".join([f"{i+1:4d}{'>' if i+1==lineno else ' '} {line}" for i, line in enumerate(lines[start:end])])
            snippet += "\n..."
            
            return snippet
        except Exception as e:
            return f"No se pudo obtener fragmento de código: {e}"
        finally:
            del frame  # Evitar ciclos de referencia
    
    def handle_error(self, error_msg: str, code_context: Optional[str] = None, exception: Optional[Exception] = None):
        """
        Registra un error y potencialmente activa la autocorrección.
        
        Args:
            error_msg: Mensaje de error.
            code_context: Contexto de código donde ocurrió el error.
            exception: Excepción que causó el error.
        """
        logger.error(f"Error manejado: {error_msg}")
        
        error_data = {
            "timestamp": time.time(),
            "message": error_msg,
            "context": code_context or "No se proporcionó contexto.",
            "exception_type": type(exception).__name__ if exception else "N/A"
        }
        
        self.error_history.append(error_data)
        
        # Activar autocorrección si está habilitada y el sistema está disponible
        if PARAMETERS["SELF_CORRECTION_ENABLED"] and self.error_correction_system and exception:
            logger.info("Reenviando error al sistema de autocorrección...")
            
            try:
                # Placeholder - Implementar cuando se desarrolle el sistema de corrección de errores
                pass
            except Exception as correction_e:
                logger.error(f"Error ocurrido *dentro* del sistema de manejo de errores: {correction_e}", exc_info=True)
    
    def apply_code_modification(self, original_snippet: str, new_snippet: str) -> bool:
        """
        Reemplaza el fragmento original con el nuevo en el archivo fuente.
        ADVERTENCIA: EXTREMADAMENTE PELIGROSO. Modifica el archivo de script en ejecución.
        
        Args:
            original_snippet: Fragmento original a reemplazar.
            new_snippet: Nuevo fragmento.
            
        Returns:
            True si la modificación se aplicó correctamente, False en caso contrario.
        """
        # Placeholder - Implementar cuando se desarrolle el sistema de automejora
        logger.warning("Aplicación de modificación de código: implementación pendiente.")
        return False
    
    # --- Gestión de estado ---
    
    def save_state(self):
        """Guarda el estado completo del sistema NEBULA."""
        logger.info(f"Guardando estado de NEBULA en {PARAMETERS['STATE_FILE']}...")
        
        state = {
            "version": self.VERSION,
            "timestamp": time.time(),
            "iteration": self.iteration,
            "space_state": self.space.get_space_state() if self.space else None,
            "knowledge_graph_state": None,  # Implementar cuando se desarrolle KnowledgeGraph
            "holographic_memory_state": None,  # Implementar cuando se desarrolle HolographicMemory
            "genome_state": None,  # Implementar cuando se desarrolle NebulaGenome
            "error_history": list(self.error_history),
            "modification_history": list(self.modification_history),
            "performance_history": list(self.performance_history),
            # Guardar IDs siguientes directamente desde space
            "next_neuron_id": self.space.next_neuron_id if self.space else 0,
            "next_cluster_id": self.space.next_cluster_id if self.space else 0,
            "next_sector_id": self.space.next_sector_id if self.space else 0,
        }
        
        try:
            # Usar pickle para guardar objetos complejos
            # Añadir mecanismo de respaldo
            state_file = PARAMETERS["STATE_FILE"]
            backup_file = PARAMETERS["BACKUP_DIRECTORY"] / f"nebula_state_backup_{time.strftime('%Y%m%d_%H%M%S')}.pkl"
            
            # Guardar primero en archivo temporal
            temp_file = state_file.with_suffix(".pkl.tmp")
            with open(temp_file, 'wb') as f:
                pickle.dump(state, f, protocol=pickle.HIGHEST_PROTOCOL)
            
            # Crear respaldo del archivo de estado existente si existe
            if state_file.exists():
                try:
                    shutil.copyfile(state_file, backup_file)
                    logger.info(f"Creado respaldo del estado anterior: {backup_file}")
                except Exception as bk_e:
                    logger.warning(f"No se pudo crear respaldo de estado: {bk_e}")
            
            # Reemplazar atómicamente el archivo de estado antiguo con el nuevo
            os.replace(temp_file, state_file)
            
            self.last_backup_time = time.time()
            logger.info("Estado de NEBULA guardado correctamente.")
        except Exception as e:
            logger.error(f"Error al guardar estado de NEBULA: {e}", exc_info=True)
            # Limpiar archivo temporal si falló el guardado
            if temp_file.exists():
                os.remove(temp_file)
    
    def load_state(self):
        """Carga el estado del sistema desde el archivo."""
        state_file = PARAMETERS["STATE_FILE"]
        
        if state_file.exists():
            logger.info(f"Cargando estado de NEBULA desde {state_file}...")
            
            try:
                with open(state_file, 'rb') as f:
                    state = pickle.load(f)
                
                # Verificar compatibilidad de versión
                loaded_version = state.get("version", "N/A")
                if loaded_version != self.VERSION:
                    logger.warning(f"Cargando estado de versión diferente (Estado: {loaded_version}, Actual: {self.VERSION}). Pueden surgir problemas de compatibilidad.")
                
                self.iteration = state.get("iteration", 0)
                self.error_history = deque(state.get("error_history", []), maxlen=PARAMETERS["MAX_ERROR_HISTORY"])
                self.modification_history = deque(state.get("modification_history", []), maxlen=PARAMETERS["MAX_MODIFICATION_HISTORY"])
                self.performance_history = deque(state.get("performance_history", []), maxlen=200)
                self.last_backup_time = state.get("timestamp", 0)
                
                # Cargar componentes (si existe estado para ellos)
                if state.get("space_state") and self.space:
                    self.space.load_space_state(state["space_state"])
                    # Restaurar IDs siguientes desde estado si están disponibles
                    self.space.next_neuron_id = state.get("next_neuron_id", self.space.next_neuron_id)
                    self.space.next_cluster_id = state.get("next_cluster_id", self.space.next_cluster_id)
                    self.space.next_sector_id = state.get("next_sector_id", self.space.next_sector_id)
                
                # Placeholder - Implementar carga de otros componentes cuando se desarrollen
                
                logger.info("Estado de NEBULA cargado correctamente.")
                
            except EOFError:
                logger.error("Error al cargar estado: Archivo de estado corrupto o vacío.")
                self._handle_corrupted_state()
            except Exception as e:
                logger.error(f"Error al cargar estado de NEBULA: {e}", exc_info=True)
                self._handle_corrupted_state()
        else:
            logger.info("No se encontró archivo de estado. Iniciando NEBULA con configuración inicial.")
    
    def _handle_corrupted_state(self):
        """Intenta cargar el último respaldo si el archivo de estado está corrupto."""
        logger.warning("Intentando cargar desde el último respaldo debido a error de carga de archivo de estado...")
        
        backup_dir = PARAMETERS["BACKUP_DIRECTORY"]
        try:
            backups = sorted(backup_dir.glob("nebula_state_backup_*.pkl"), key=os.path.getmtime, reverse=True)
            
            if backups:
                latest_backup = backups[0]
                logger.info(f"Encontrado último respaldo: {latest_backup}")
                
                # Intentar cargar el respaldo
                with open(latest_backup, 'rb') as f:
                    state = pickle.load(f)
                
                # Si la carga del respaldo funciona, copiarlo al archivo de estado principal
                shutil.copyfile(latest_backup, PARAMETERS["STATE_FILE"])
                logger.info(f"Estado cargado correctamente desde respaldo y archivo de estado restaurado.")
                
                # Ahora llamar a load_state nuevamente para cargar los datos restaurados
                self.load_state()
            else:
                logger.error("No se encontraron archivos de respaldo. Iniciando con estado nuevo.")
                # Inicializar explícitamente space si es necesario
                if self.space:
                    self.space.initialize_neurons(PARAMETERS["INITIAL_NEURONS"])
        
        except Exception as e:
            logger.error(f"Error al cargar estado desde respaldo: {e}. Iniciando con estado nuevo.", exc_info=True)
            # Asegurar que space está inicializado si falla toda la carga
            if self.space:
                self.space.initialize_neurons(PARAMETERS["INITIAL_NEURONS"])
    
    # --- Monitoreo e información ---
    
    def get_statistics_dict(self) -> Dict:
        """
        Devuelve un diccionario con estadísticas actuales del sistema.
        
        Returns:
            Diccionario con estadísticas del sistema.
        """
        stats = {
            "Iteración": self.iteration,
            "Tiempo activo (s)": int(time.time() - self.start_time),
            "Neuronas": len(self.space.neurons) if self.space else 0,
            "Clusters": len(self.space.clusters) if self.space else 0,
            "Sectores": len(self.space.sectors) if self.space else 0,
            "Conexiones (Grafo)": self.space.connection_graph.number_of_edges() if self.space else 0,
            "Nodos KG": 0,  # Implementar cuando se desarrolle KnowledgeGraph
            "Aristas KG": 0,  # Implementar cuando se desarrolle KnowledgeGraph
            "Items Memoria Holo": 0,  # Implementar cuando se desarrolle HolographicMemory
            "Errores Registrados": len(self.error_history),
            "Modificaciones Aplicadas": len(self.modification_history),
            "Rendimiento Promedio (Últimos 20)": f"{np.mean(list(self.performance_history)[-20:]):.3f}" if self.performance_history else "N/A",
            "Uso RAM (%)": f"{self._get_ram_usage():.1f}",
            "Uso GPU (%)": f"{self._get_gpu_usage():.1f}" if self.device.type == 'cuda' else "N/A",
        }
        
        return stats
    
    def _get_ram_usage(self) -> float:
        """
        Obtiene el porcentaje de uso de RAM.
        
        Returns:
            Porcentaje de uso de RAM.
        """
        import psutil
        return psutil.virtual_memory().percent
    
    def _get_gpu_usage(self) -> float:
        """
        Obtiene el porcentaje de uso de GPU.
        
        Returns:
            Porcentaje de uso de GPU o 0.0 si no está disponible.
        """
        if self.device.type != 'cuda':
            return 0.0
        
        try:
            import GPUtil
            gpus = GPUtil.getGPUs()
            if gpus:
                gpu = gpus[0]  # Asumir una sola GPU por simplicidad
                return gpu.load * 100
        except ImportError:
            pass
        
        return 0.0
    
    def display_statistics(self):
        """Muestra estadísticas actuales del sistema."""
        stats = self.get_statistics_dict()
        
        logger.info("=== Estadísticas de NEBULA ===")
        for key, value in stats.items():
            logger.info(f"{key}: {value}")
        logger.info("=============================")
    
    def shutdown(self):
        """Realiza un apagado ordenado del sistema."""
        logger.info("Iniciando apagado ordenado de NEBULA...")
        
        self.shutdown_requested = True
        
        # Guardar estado final
        try:
            self.save_state()
        except Exception as e:
            logger.error(f"Error al guardar estado durante apagado: {e}")
        
        # Descargar modelos LLM
        for model_key in list(self.llm_models.keys()):
            try:
                self.unload_llm_model(model_key, force=True)
            except:
                pass
        
        # Forzar liberación de memoria
        gc.collect()
        if self.device.type == 'cuda':
            torch.cuda.empty_cache()
        
        logger.info("Apagado de NEBULA completado.")
    
    def unload_llm_model(self, model_key: str, force: bool = False):
        """
        Descarga un modelo LLM para liberar memoria.
        
        Args:
            model_key: Clave del modelo a descargar.
            force: Si es True, fuerza la descarga incluso si el modelo está en uso.
        """
        # Placeholder - Implementar cuando se desarrolle el módulo de LLM
        logger.debug(f"Descarga de modelo LLM '{model_key}': implementación pendiente.")
