"""
Implementación del Optimizador Automático para NEBULA.

Esta clase proporciona mecanismos para la automejora del sistema NEBULA,
permitiendo optimizar su propio código y configuración.
"""

import logging
import time
import os
import re
import ast
import importlib
import sys
import shutil
import subprocess
from typing import Any, Dict, List, Optional, Tuple, Union, Set
from pathlib import Path
import json
import tempfile

from utils.config import PARAMETERS
from utils.helpers import safe_loop

logger = logging.getLogger("NEBULA.SelfOptimizer")

class SelfOptimizer:
    """
    Optimizador automático que permite a NEBULA mejorar su propio código
    y configuración de forma autónoma.
    
    Características:
    - Optimización de parámetros de configuración
    - Refactorización automática de código
    - Implementación de mejoras sugeridas
    - Pruebas automáticas de cambios
    - Gestión de versiones y rollback
    """
    
    def __init__(self, evolution_engine=None, code_analyzer=None, llm_manager=None):
        """
        Inicializa el optimizador automático.
        
        Args:
            evolution_engine: Motor de evolución para optimización de parámetros.
            code_analyzer: Analizador de código para evaluación y sugerencias.
            llm_manager: Gestor de modelos LLM para generación de código.
        """
        logger.info("Inicializando SelfOptimizer...")
        self.evolution_engine = evolution_engine
        self.code_analyzer = code_analyzer
        self.llm_manager = llm_manager
        
        # Directorio raíz del proyecto
        self.project_root = Path(PARAMETERS["PROJECT_ROOT"])
        
        # Directorio para backups y versiones
        self.versions_dir = PARAMETERS["BACKUP_DIRECTORY"] / "versions"
        os.makedirs(self.versions_dir, exist_ok=True)
        
        # Historial de optimizaciones
        self.optimization_history = []
        
        # Contadores y estadísticas
        self.total_optimizations = 0
        self.successful_optimizations = 0
        self.last_optimization_time = 0
        
        # Configuración de seguridad
        self.safety_checks = {
            "backup_before_changes": True,
            "run_tests_after_changes": True,
            "max_changes_per_run": 5,
            "restricted_modules": ["core", "utils"],  # Módulos con restricciones adicionales
            "allow_structural_changes": False,  # Cambios en estructura de clases/métodos
            "allow_config_changes": True,  # Cambios en parámetros de configuración
        }
        
        logger.info("SelfOptimizer inicializado correctamente.")
    
    def _create_backup(self, target_path: Optional[Path] = None, version_tag: Optional[str] = None) -> Path:
        """
        Crea una copia de seguridad del código actual.
        
        Args:
            target_path: Ruta específica a respaldar (None para todo el proyecto).
            version_tag: Etiqueta de versión (None para timestamp).
            
        Returns:
            Ruta al directorio de backup.
        """
        timestamp = int(time.time())
        version_tag = version_tag or f"backup_{timestamp}"
        
        # Determinar directorio de origen
        source_dir = target_path if target_path else self.project_root
        
        # Crear directorio de backup
        backup_dir = self.versions_dir / version_tag
        os.makedirs(backup_dir, exist_ok=True)
        
        try:
            # Copiar archivos
            if target_path and target_path.is_file():
                # Backup de un solo archivo
                dest_file = backup_dir / target_path.name
                shutil.copy2(target_path, dest_file)
                logger.info(f"Backup creado para archivo {target_path} en {dest_file}")
            else:
                # Backup de directorio
                if target_path:
                    # Copiar solo el directorio específico
                    dest_dir = backup_dir / target_path.name
                    shutil.copytree(target_path, dest_dir)
                    logger.info(f"Backup creado para directorio {target_path} en {dest_dir}")
                else:
                    # Copiar todo el proyecto
                    for item in source_dir.iterdir():
                        if item.is_dir() and not item.name.startswith('.') and item.name != 'versions':
                            dest_dir = backup_dir / item.name
                            shutil.copytree(item, dest_dir)
                        elif item.is_file():
                            dest_file = backup_dir / item.name
                            shutil.copy2(item, dest_file)
                    
                    logger.info(f"Backup completo del proyecto creado en {backup_dir}")
            
            # Crear archivo de metadatos
            metadata = {
                "timestamp": timestamp,
                "version_tag": version_tag,
                "source": str(source_dir),
                "created_by": "SelfOptimizer",
                "description": f"Backup automático antes de optimización"
            }
            
            with open(backup_dir / "backup_metadata.json", 'w') as f:
                json.dump(metadata, f, indent=2)
            
            return backup_dir
        
        except Exception as e:
            logger.error(f"Error al crear backup: {e}")
            # Intentar limpiar en caso de error
            if backup_dir.exists():
                try:
                    shutil.rmtree(backup_dir)
                except:
                    pass
            raise
    
    def _restore_from_backup(self, backup_path: Path) -> bool:
        """
        Restaura el código desde una copia de seguridad.
        
        Args:
            backup_path: Ruta al directorio de backup.
            
        Returns:
            True si la restauración fue exitosa, False en caso contrario.
        """
        if not backup_path.exists() or not backup_path.is_dir():
            logger.error(f"Directorio de backup no encontrado: {backup_path}")
            return False
        
        try:
            # Verificar metadata
            metadata_file = backup_path / "backup_metadata.json"
            if metadata_file.exists():
                with open(metadata_file, 'r') as f:
                    metadata = json.load(f)
                
                source = metadata.get("source")
                if source:
                    source_path = Path(source)
                    
                    # Determinar si es backup de archivo, directorio o proyecto completo
                    if source_path.is_file():
                        # Restaurar archivo
                        backup_file = backup_path / source_path.name
                        if backup_file.exists():
                            shutil.copy2(backup_file, source_path)
                            logger.info(f"Archivo {source_path} restaurado desde {backup_file}")
                            return True
                    else:
                        # Restaurar directorio o proyecto
                        for item in backup_path.iterdir():
                            if item.name == "backup_metadata.json":
                                continue
                            
                            if item.is_dir():
                                dest_dir = self.project_root / item.name
                                if dest_dir.exists():
                                    shutil.rmtree(dest_dir)
                                shutil.copytree(item, dest_dir)
                            elif item.is_file():
                                dest_file = self.project_root / item.name
                                shutil.copy2(item, dest_file)
                        
                        logger.info(f"Proyecto restaurado desde backup {backup_path}")
                        return True
            
            # Si no hay metadata o falló la restauración basada en metadata,
            # intentar restauración genérica
            for item in backup_path.iterdir():
                if item.name == "backup_metadata.json":
                    continue
                
                if item.is_dir():
                    dest_dir = self.project_root / item.name
                    if dest_dir.exists():
                        shutil.rmtree(dest_dir)
                    shutil.copytree(item, dest_dir)
                elif item.is_file():
                    dest_file = self.project_root / item.name
                    shutil.copy2(item, dest_file)
            
            logger.info(f"Proyecto restaurado desde backup {backup_path}")
            return True
        
        except Exception as e:
            logger.error(f"Error al restaurar desde backup: {e}")
            return False
    
    def _run_tests(self, target_module: Optional[str] = None) -> Dict[str, Any]:
        """
        Ejecuta pruebas para verificar la integridad del sistema.
        
        Args:
            target_module: Módulo específico a probar (None para todos).
            
        Returns:
            Diccionario con resultados de pruebas.
        """
        start_time = time.time()
        
        # Directorio de pruebas
        tests_dir = self.project_root / "tests"
        
        if not tests_dir.exists():
            logger.warning(f"Directorio de pruebas no encontrado: {tests_dir}")
            return {
                "status": "error",
                "error": "Directorio de pruebas no encontrado",
                "passed": False
            }
        
        try:
            # Determinar pruebas a ejecutar
            if target_module:
                test_pattern = f"test_{target_module}*.py"
                test_files = list(tests_dir.glob(test_pattern))
                
                if not test_files:
                    logger.warning(f"No se encontraron pruebas para el módulo {target_module}")
                    return {
                        "status": "warning",
                        "warning": f"No se encontraron pruebas para el módulo {target_module}",
                        "passed": True  # Asumir éxito si no hay pruebas
                    }
            else:
                test_files = list(tests_dir.glob("test_*.py"))
                
                if not test_files:
                    logger.warning("No se encontraron archivos de prueba")
                    return {
                        "status": "warning",
                        "warning": "No se encontraron archivos de prueba",
                        "passed": True  # Asumir éxito si no hay pruebas
                    }
            
            # Ejecutar pruebas
            results = []
            all_passed = True
            
            for test_file in test_files:
                logger.info(f"Ejecutando pruebas en {test_file}")
                
                # Ejecutar prueba en proceso separado
                result = subprocess.run(
                    [sys.executable, str(test_file)],
                    capture_output=True,
                    text=True,
                    cwd=str(self.project_root)
                )
                
                test_passed = result.returncode == 0
                all_passed = all_passed and test_passed
                
                results.append({
                    "file": str(test_file),
                    "passed": test_passed,
                    "returncode": result.returncode,
                    "stdout": result.stdout,
                    "stderr": result.stderr
                })
            
            return {
                "status": "success",
                "passed": all_passed,
                "test_count": len(test_files),
                "results": results,
                "execution_time": time.time() - start_time
            }
        
        except Exception as e:
            logger.error(f"Error al ejecutar pruebas: {e}")
            return {
                "status": "error",
                "error": str(e),
                "passed": False
            }
    
    def _validate_code_changes(self, original_code: str, modified_code: str) -> Dict[str, Any]:
        """
        Valida cambios en el código para asegurar que son seguros.
        
        Args:
            original_code: Código original.
            modified_code: Código modificado.
            
        Returns:
            Diccionario con resultado de validación.
        """
        try:
            # Verificar que el código modificado es sintácticamente válido
            try:
                ast.parse(modified_code)
            except SyntaxError as e:
                return {
                    "valid": False,
                    "error": f"Error de sintaxis: {str(e)}",
                    "line": e.lineno,
                    "offset": e.offset
                }
            
            # Analizar cambios estructurales
            original_tree = ast.parse(original_code)
            modified_tree = ast.parse(modified_code)
            
            # Extraer clases y funciones originales
            original_classes = {node.name: node for node in ast.walk(original_tree) if isinstance(node, ast.ClassDef)}
            original_functions = {node.name: node for node in ast.walk(original_tree) if isinstance(node, ast.FunctionDef)}
            
            # Extraer clases y funciones modificadas
            modified_classes = {node.name: node for node in ast.walk(modified_tree) if isinstance(node, ast.ClassDef)}
            modified_functions = {node.name: node for node in ast.walk(modified_tree) if isinstance(node, ast.FunctionDef)}
            
            # Verificar eliminación de clases o funciones
            removed_classes = set(original_classes.keys()) - set(modified_classes.keys())
            removed_functions = set(original_functions.keys()) - set(modified_functions.keys())
            
            if removed_classes and not self.safety_checks["allow_structural_changes"]:
                return {
                    "valid": False,
                    "error": f"Eliminación de clases no permitida: {', '.join(removed_classes)}",
                    "structural_changes": True
                }
            
            if removed_functions and not self.safety_checks["allow_structural_changes"]:
                return {
                    "valid": False,
                    "error": f"Eliminación de funciones no permitida: {', '.join(removed_functions)}",
                    "structural_changes": True
                }
            
            # Verificar cambios en firmas de métodos
            for func_name, orig_func in original_functions.items():
                if func_name in modified_functions:
                    mod_func = modified_functions[func_name]
                    
                    # Comparar argumentos
                    orig_args = [arg.arg for arg in orig_func.args.args]
                    mod_args = [arg.arg for arg in mod_func.args.args]
                    
                    if orig_args != mod_args and not self.safety_checks["allow_structural_changes"]:
                        return {
                            "valid": False,
                            "error": f"Cambio en firma de función no permitido: {func_name}",
                            "structural_changes": True
                        }
            
            # Verificar importaciones sospechosas
            suspicious_imports = ["os.system", "subprocess", "eval", "exec", "__import__"]
            
            for node in ast.walk(modified_tree):
                if isinstance(node, ast.Import):
                    for name in node.names:
                        if name.name in ["os", "subprocess", "sys"]:
                            # Verificar si estas importaciones ya existían
                            existed = False
                            for orig_node in ast.walk(original_tree):
                                if isinstance(orig_node, ast.Import):
                                    for orig_name in orig_node.names:
                                        if orig_name.name == name.name:
                                            existed = True
                                            break
                            
                            if not existed:
                                return {
                                    "valid": False,
                                    "error": f"Importación sospechosa añadida: {name.name}",
                                    "security_risk": True
                                }
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module in ["os", "subprocess", "sys"]:
                        for name in node.names:
                            full_import = f"{node.module}.{name.name}"
                            if full_import in suspicious_imports:
                                # Verificar si ya existía
                                existed = False
                                for orig_node in ast.walk(original_tree):
                                    if isinstance(orig_node, ast.ImportFrom) and orig_node.module == node.module:
                                        for orig_name in orig_node.names:
                                            if orig_name.name == name.name:
                                                existed = True
                                                break
                                
                                if not existed:
                                    return {
                                        "valid": False,
                                        "error": f"Importación sospechosa añadida: {full_import}",
                                        "security_risk": True
                                    }
            
            # Verificar uso de eval o exec
            for node in ast.walk(modified_tree):
                if isinstance(node, ast.Call) and hasattr(node.func, 'id'):
                    if node.func.id in ["eval", "exec"]:
                        # Verificar si ya existía
                        existed = False
                        for orig_node in ast.walk(original_tree):
                            if isinstance(orig_node, ast.Call) and hasattr(orig_node.func, 'id'):
                                if orig_node.func.id == node.func.id:
                                    existed = True
                                    break
                        
                        if not existed:
                            return {
                                "valid": False,
                                "error": f"Uso sospechoso de {node.func.id}()",
                                "security_risk": True
                            }
            
            # Si llegamos aquí, los cambios son válidos
            return {
                "valid": True,
                "added_classes": list(set(modified_classes.keys()) - set(original_classes.keys())),
                "added_functions": list(set(modified_functions.keys()) - set(original_functions.keys())),
                "modified_functions": [
                    func_name for func_name in set(original_functions.keys()).intersection(set(modified_functions.keys()))
                    if ast.unparse(original_functions[func_name]) != ast.unparse(modified_functions[func_name])
                ]
            }
        
        except Exception as e:
            logger.error(f"Error al validar cambios de código: {e}")
            return {
                "valid": False,
                "error": f"Error en validación: {str(e)}"
            }
    
    def _apply_code_changes(self, file_path: Path, modified_code: str) -> bool:
        """
        Aplica cambios al código fuente.
        
        Args:
            file_path: Ruta al archivo a modificar.
            modified_code: Código modificado.
            
        Returns:
            True si los cambios se aplicaron correctamente, False en caso contrario.
        """
        try:
            # Leer código original
            with open(file_path, 'r', encoding='utf-8') as f:
                original_code = f.read()
            
            # Validar cambios
            validation = self._validate_code_changes(original_code, modified_code)
            
            if not validation["valid"]:
                logger.error(f"Validación de cambios fallida: {validation['error']}")
                return False
            
            # Crear backup
            if self.safety_checks["backup_before_changes"]:
                self._create_backup(file_path)
            
            # Aplicar cambios
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(modified_code)
            
            logger.info(f"Cambios aplicados a {file_path}")
            
            # Ejecutar pruebas si es necesario
            if self.safety_checks["run_tests_after_changes"]:
                # Determinar módulo afectado
                rel_path = file_path.relative_to(self.project_root)
                module_parts = str(rel_path).split(os.sep)
                
                if len(module_parts) > 1:
                    module_name = module_parts[0]
                    test_results = self._run_tests(module_name)
                    
                    if not test_results["passed"]:
                        logger.error(f"Pruebas fallidas después de cambios en {file_path}")
                        
                        # Restaurar desde backup
                        backups = sorted([d for d in self.versions_dir.iterdir() if d.is_dir()], 
                                        key=lambda x: int(x.name.split('_')[-1]) if x.name.split('_')[-1].isdigit() else 0,
                                        reverse=True)
                        
                        if backups:
                            latest_backup = backups[0]
                            logger.info(f"Restaurando desde backup {latest_backup}")
                            
                            # Restaurar solo el archivo modificado
                            backup_file = latest_backup / file_path.name
                            if backup_file.exists():
                                shutil.copy2(backup_file, file_path)
                                logger.info(f"Archivo {file_path} restaurado desde {backup_file}")
                                return False
                        
                        return False
            
            return True
        
        except Exception as e:
            logger.error(f"Error al aplicar cambios de código: {e}")
            return False
    
    def optimize_parameters(self, module_name: str, param_specs: List[Dict[str, Any]], 
                          evaluation_function: callable, **kwargs) -> Dict[str, Any]:
        """
        Optimiza parámetros de configuración mediante algoritmos evolutivos.
        
        Args:
            module_name: Nombre del módulo a optimizar.
            param_specs: Especificaciones de parámetros a optimizar.
            evaluation_function: Función para evaluar conjuntos de parámetros.
            **kwargs: Argumentos adicionales para el algoritmo evolutivo.
            
        Returns:
            Diccionario con resultados de optimización.
        """
        if not self.evolution_engine:
            logger.error("Evolution Engine no disponible para optimización de parámetros")
            return {
                "status": "error",
                "error": "Evolution Engine no disponible"
            }
        
        start_time = time.time()
        
        try:
            logger.info(f"Iniciando optimización de parámetros para módulo {module_name}")
            
            # Configurar parámetros de evolución
            pop_size = kwargs.get('pop_size', 30)
            n_generations = kwargs.get('n_generations', 15)
            
            # Ejecutar evolución
            results = self.evolution_engine.evolve_parameters(
                param_type='mixed',
                param_config=param_specs,
                eval_function=evaluation_function,
                pop_size=pop_size,
                n_generations=n_generations,
                checkpoint_freq=5
            )
            
            if 'error' in results:
                logger.error(f"Error en optimización de parámetros: {results['error']}")
                return {
                    "status": "error",
                    "error": results['error'],
                    "module": module_name
                }
            
            # Actualizar estadísticas
            self.total_optimizations += 1
            self.successful_optimizations += 1
            self.last_optimization_time = time.time()
            
            # Guardar en historial
            optimization_record = {
                "type": "parameter_optimization",
                "module": module_name,
                "timestamp": time.time(),
                "duration": time.time() - start_time,
                "best_params": results['best_params'],
                "best_fitness": results['best_fitness']
            }
            
            self.optimization_history.append(optimization_record)
            
            return {
                "status": "success",
                "module": module_name,
                "best_params": results['best_params'],
                "best_fitness": results['best_fitness'],
                "optimization_time": time.time() - start_time,
                "evolution_results": results
            }
        
        except Exception as e:
            logger.error(f"Error en optimización de parámetros: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "module": module_name
            }
    
    def update_configuration(self, config_updates: Dict[str, Any]) -> Dict[str, Any]:
        """
        Actualiza parámetros de configuración del sistema.
        
        Args:
            config_updates: Diccionario con actualizaciones de configuración.
            
        Returns:
            Diccionario con resultado de la actualización.
        """
        if not self.safety_checks["allow_config_changes"]:
            logger.warning("Cambios de configuración no permitidos por configuración de seguridad")
            return {
                "status": "error",
                "error": "Cambios de configuración no permitidos"
            }
        
        try:
            # Ruta al archivo de configuración
            config_file = self.project_root / "utils" / "config.py"
            
            if not config_file.exists():
                logger.error(f"Archivo de configuración no encontrado: {config_file}")
                return {
                    "status": "error",
                    "error": "Archivo de configuración no encontrado"
                }
            
            # Leer configuración actual
            with open(config_file, 'r', encoding='utf-8') as f:
                config_code = f.read()
            
            # Parsear configuración
            tree = ast.parse(config_code)
            
            # Buscar diccionario PARAMETERS
            parameters_node = None
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id == "PARAMETERS":
                            parameters_node = node.value
                            break
            
            if not parameters_node or not isinstance(parameters_node, ast.Dict):
                logger.error("No se encontró el diccionario PARAMETERS en el archivo de configuración")
                return {
                    "status": "error",
                    "error": "Estructura de configuración no reconocida"
                }
            
            # Crear backup
            if self.safety_checks["backup_before_changes"]:
                self._create_backup(config_file)
            
            # Modificar configuración usando regex para preservar comentarios
            updated_config = config_code
            
            for key, value in config_updates.items():
                # Escapar caracteres especiales en la clave
                escaped_key = re.escape(key)
                
                # Patrón para buscar la clave en el diccionario
                pattern = rf'"{escaped_key}"\s*:\s*[^,\n]++'
                
                # Formatear el nuevo valor según su tipo
                if isinstance(value, str):
                    new_value = f'"{key}": "{value}"'
                elif isinstance(value, bool):
                    new_value = f'"{key}": {"True" if value else "False"}'
                elif isinstance(value, (int, float)):
                    new_value = f'"{key}": {value}'
                elif isinstance(value, list):
                    new_value = f'"{key}": {value}'
                elif isinstance(value, dict):
                    new_value = f'"{key}": {value}'
                else:
                    new_value = f'"{key}": {value}'
                
                # Reemplazar en la configuración
                match = re.search(pattern, updated_config)
                if match:
                    updated_config = updated_config.replace(match.group(0), new_value)
                else:
                    # Si la clave no existe, añadirla al final del diccionario
                    # Buscar el final del diccionario PARAMETERS
                    dict_end = re.search(r'}\s*\n', updated_config)
                    if dict_end:
                        # Insertar antes del cierre del diccionario
                        pos = dict_end.start()
                        updated_config = updated_config[:pos] + f'    {new_value},\n' + updated_config[pos:]
            
            # Aplicar cambios
            with open(config_file, 'w', encoding='utf-8') as f:
                f.write(updated_config)
            
            logger.info(f"Configuración actualizada con {len(config_updates)} parámetros")
            
            # Actualizar estadísticas
            self.total_optimizations += 1
            self.successful_optimizations += 1
            self.last_optimization_time = time.time()
            
            # Guardar en historial
            optimization_record = {
                "type": "config_update",
                "timestamp": time.time(),
                "updates": config_updates
            }
            
            self.optimization_history.append(optimization_record)
            
            # Recargar configuración
            try:
                importlib.reload(sys.modules['utils.config'])
                logger.info("Módulo de configuración recargado")
            except Exception as e:
                logger.warning(f"No se pudo recargar el módulo de configuración: {e}")
            
            return {
                "status": "success",
                "updated_params": list(config_updates.keys()),
                "config_file": str(config_file)
            }
        
        except Exception as e:
            logger.error(f"Error al actualizar configuración: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e)
            }
    
    @safe_loop(max_retries=2, delay=1)
    def refactor_code(self, file_path: Path) -> Dict[str, Any]:
        """
        Refactoriza código para mejorar su calidad y rendimiento.
        
        Args:
            file_path: Ruta al archivo a refactorizar.
            
        Returns:
            Diccionario con resultado de la refactorización.
        """
        if not self.code_analyzer:
            logger.error("Code Analyzer no disponible para refactorización")
            return {
                "status": "error",
                "error": "Code Analyzer no disponible"
            }
        
        if not self.llm_manager:
            logger.error("LLM Manager no disponible para refactorización")
            return {
                "status": "error",
                "error": "LLM Manager no disponible"
            }
        
        start_time = time.time()
        
        try:
            logger.info(f"Iniciando refactorización de {file_path}")
            
            # Verificar existencia del archivo
            if not file_path.exists():
                logger.error(f"Archivo no encontrado: {file_path}")
                return {
                    "status": "error",
                    "error": "Archivo no encontrado",
                    "file_path": str(file_path)
                }
            
            # Analizar código
            analysis = self.code_analyzer.analyze_file(file_path)
            
            if analysis['status'] != 'success':
                logger.error(f"Error al analizar archivo: {analysis.get('error', 'Error desconocido')}")
                return {
                    "status": "error",
                    "error": analysis.get('error', 'Error en análisis'),
                    "file_path": str(file_path)
                }
            
            # Verificar si hay problemas que resolver
            if analysis['total_issues'] == 0 and analysis['quality_score'] >= 8.0:
                logger.info(f"El archivo {file_path} ya tiene buena calidad (puntuación: {analysis['quality_score']:.1f}). No se requiere refactorización.")
                return {
                    "status": "success",
                    "message": "No se requiere refactorización",
                    "file_path": str(file_path),
                    "quality_score": analysis['quality_score'],
                    "changes_made": False
                }
            
            # Leer código original
            with open(file_path, 'r', encoding='utf-8') as f:
                original_code = f.read()
            
            # Generar sugerencias de mejora
            suggestions = self.code_analyzer.generate_improvement_suggestions(analysis)
            
            if suggestions['status'] != 'success':
                logger.error(f"Error al generar sugerencias: {suggestions.get('error', 'Error desconocido')}")
                return {
                    "status": "error",
                    "error": suggestions.get('error', 'Error en generación de sugerencias'),
                    "file_path": str(file_path)
                }
            
            # Limitar número de sugerencias a implementar
            specific_suggestions = suggestions['specific_suggestions']
            if len(specific_suggestions) > self.safety_checks["max_changes_per_run"]:
                # Priorizar por importancia
                specific_suggestions.sort(key=lambda x: 0 if x['importance'] == 'high' else 1 if x['importance'] == 'medium' else 2)
                specific_suggestions = specific_suggestions[:self.safety_checks["max_changes_per_run"]]
            
            # Si no hay sugerencias específicas, no continuar
            if not specific_suggestions:
                logger.info(f"No hay sugerencias específicas para implementar en {file_path}")
                return {
                    "status": "success",
                    "message": "No hay sugerencias específicas para implementar",
                    "file_path": str(file_path),
                    "quality_score": analysis['quality_score'],
                    "changes_made": False
                }
            
            # Generar prompt para LLM
            prompt = f"""Refactoriza el siguiente código Python para mejorar su calidad y rendimiento.

Implementa SOLO las siguientes mejoras específicas:
"""
            
            for i, suggestion in enumerate(specific_suggestions, 1):
                prompt += f"\n{i}. {suggestion['description']}"
                if 'file' in suggestion and 'line' in suggestion:
                    prompt += f" (línea {suggestion['line']})"
            
            prompt += f"""

Código original:
```python
{original_code}
```

Instrucciones importantes:
1. Mantén EXACTAMENTE la misma funcionalidad
2. No elimines clases, métodos o funciones existentes
3. No cambies las firmas de los métodos (parámetros y tipos)
4. Mejora la documentación y legibilidad donde sea necesario
5. Devuelve SOLO el código refactorizado completo, sin explicaciones

Código refactorizado:
```python
"""
            
            # Generar código refactorizado
            refactored_code = self.llm_manager.generate_text(prompt, max_length=len(original_code) + 500, model_size="large")
            
            # Limpiar resultado
            if "```python" in refactored_code:
                refactored_code = refactored_code.split("```python")[1]
            if "```" in refactored_code:
                refactored_code = refactored_code.split("```")[0]
            
            refactored_code = refactored_code.strip()
            
            # Validar cambios
            validation = self._validate_code_changes(original_code, refactored_code)
            
            if not validation["valid"]:
                logger.error(f"Validación de cambios fallida: {validation['error']}")
                return {
                    "status": "error",
                    "error": f"Validación de cambios fallida: {validation['error']}",
                    "file_path": str(file_path)
                }
            
            # Aplicar cambios
            success = self._apply_code_changes(file_path, refactored_code)
            
            if not success:
                logger.error(f"Error al aplicar cambios a {file_path}")
                return {
                    "status": "error",
                    "error": "Error al aplicar cambios",
                    "file_path": str(file_path)
                }
            
            # Analizar código refactorizado
            new_analysis = self.code_analyzer.analyze_file(file_path)
            
            # Verificar mejora
            quality_improved = False
            if new_analysis['status'] == 'success':
                quality_improved = new_analysis['quality_score'] > analysis['quality_score']
            
            # Actualizar estadísticas
            self.total_optimizations += 1
            self.successful_optimizations += 1
            self.last_optimization_time = time.time()
            
            # Guardar en historial
            optimization_record = {
                "type": "code_refactoring",
                "file": str(file_path),
                "timestamp": time.time(),
                "duration": time.time() - start_time,
                "original_quality": analysis['quality_score'],
                "new_quality": new_analysis['quality_score'] if new_analysis['status'] == 'success' else None,
                "changes": validation.get("modified_functions", [])
            }
            
            self.optimization_history.append(optimization_record)
            
            return {
                "status": "success",
                "file_path": str(file_path),
                "original_quality": analysis['quality_score'],
                "new_quality": new_analysis['quality_score'] if new_analysis['status'] == 'success' else None,
                "quality_improved": quality_improved,
                "changes_made": True,
                "modified_functions": validation.get("modified_functions", []),
                "refactoring_time": time.time() - start_time
            }
        
        except Exception as e:
            logger.error(f"Error en refactorización: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "file_path": str(file_path)
            }
    
    def implement_improvement(self, module_name: str, improvement_description: str) -> Dict[str, Any]:
        """
        Implementa una mejora específica en un módulo.
        
        Args:
            module_name: Nombre del módulo a mejorar.
            improvement_description: Descripción detallada de la mejora.
            
        Returns:
            Diccionario con resultado de la implementación.
        """
        if not self.llm_manager:
            logger.error("LLM Manager no disponible para implementación de mejoras")
            return {
                "status": "error",
                "error": "LLM Manager no disponible"
            }
        
        start_time = time.time()
        
        try:
            logger.info(f"Iniciando implementación de mejora en módulo {module_name}")
            
            # Verificar existencia del módulo
            module_path = self.project_root / module_name
            if not module_path.exists() or not module_path.is_dir():
                logger.error(f"Módulo no encontrado: {module_path}")
                return {
                    "status": "error",
                    "error": "Módulo no encontrado",
                    "module": module_name
                }
            
            # Verificar restricciones de seguridad
            if module_name in self.safety_checks["restricted_modules"]:
                logger.warning(f"Módulo {module_name} está en la lista de restricciones. Se requieren verificaciones adicionales.")
                
                # Verificar si la mejora parece segura
                suspicious_terms = ["eliminar", "borrar", "reemplazar", "cambiar estructura", "modificar interfaz"]
                if any(term in improvement_description.lower() for term in suspicious_terms):
                    logger.error(f"La descripción de mejora contiene términos sospechosos para un módulo restringido")
                    return {
                        "status": "error",
                        "error": "La mejora propuesta puede afectar la estructura del módulo restringido",
                        "module": module_name
                    }
            
            # Crear backup del módulo
            if self.safety_checks["backup_before_changes"]:
                self._create_backup(module_path, f"before_improvement_{int(time.time())}")
            
            # Analizar módulo actual
            module_analysis = self.code_analyzer.analyze_module(module_path)
            
            if module_analysis['status'] != 'success':
                logger.error(f"Error al analizar módulo: {module_analysis.get('error', 'Error desconocido')}")
                return {
                    "status": "error",
                    "error": module_analysis.get('error', 'Error en análisis'),
                    "module": module_name
                }
            
            # Obtener archivos principales del módulo
            init_file = module_path / "__init__.py"
            if not init_file.exists():
                logger.error(f"Archivo __init__.py no encontrado en {module_path}")
                return {
                    "status": "error",
                    "error": "Estructura de módulo inválida",
                    "module": module_name
                }
            
            # Leer archivos del módulo
            module_files = {}
            for file_path in module_path.glob("*.py"):
                with open(file_path, 'r', encoding='utf-8') as f:
                    module_files[file_path.name] = f.read()
            
            # Generar prompt para LLM
            prompt = f"""Implementa la siguiente mejora en el módulo '{module_name}' de NEBULA:

Descripción de la mejora:
{improvement_description}

Estructura actual del módulo:
"""
            
            # Añadir información sobre archivos
            for filename, content in module_files.items():
                prompt += f"\n--- {filename} ---\n"
                # Añadir solo las primeras líneas para contexto
                lines = content.split('\n')
                if len(lines) > 20:
                    prompt += '\n'.join(lines[:20]) + "\n... (contenido truncado) ...\n"
                else:
                    prompt += content + "\n"
            
            prompt += f"""
Análisis del módulo:
- Total de clases: {module_analysis['total_classes']}
- Total de funciones: {module_analysis['total_functions']}
- Puntuación de calidad: {module_analysis['avg_quality_score']:.1f}/10

Instrucciones para la implementación:
1. Identifica los archivos que necesitan ser modificados
2. Para cada archivo, proporciona el código completo con las modificaciones implementadas
3. Si es necesario crear nuevos archivos, proporciona su contenido completo
4. Mantén la compatibilidad con el resto del sistema
5. Asegúrate de que las modificaciones sean coherentes con la arquitectura existente
6. Incluye documentación adecuada para las nuevas funcionalidades

Formato de respuesta:
```
ARCHIVO: nombre_archivo.py
CÓDIGO:
... código completo del archivo ...
```

Puedes repetir este formato para cada archivo que necesite ser modificado o creado.
"""
            
            # Generar implementación
            implementation = self.llm_manager.generate_text(prompt, max_length=2000, model_size="large")
            
            # Parsear respuesta
            file_changes = {}
            current_file = None
            current_code = []
            
            for line in implementation.split('\n'):
                if line.startswith("ARCHIVO:"):
                    # Guardar archivo anterior si existe
                    if current_file and current_code:
                        file_changes[current_file] = '\n'.join(current_code)
                        current_code = []
                    
                    # Nuevo archivo
                    current_file = line.replace("ARCHIVO:", "").strip()
                elif line.startswith("CÓDIGO:"):
                    # Ignorar esta línea
                    continue
                elif current_file:
                    # Añadir línea al código actual
                    current_code.append(line)
            
            # Guardar último archivo
            if current_file and current_code:
                file_changes[current_file] = '\n'.join(current_code)
            
            # Si no se detectaron cambios en el formato esperado, intentar otro enfoque
            if not file_changes:
                # Buscar bloques de código
                code_blocks = re.findall(r'```python\s+(.*?)\s+```', implementation, re.DOTALL)
                
                if code_blocks:
                    # Asumir que cada bloque es un archivo completo
                    # Intentar determinar el nombre del archivo del contexto
                    file_mentions = re.findall(r'(?:modificar|crear|actualizar|implementar en)\s+[\'"]?([a-zA-Z0-9_]+\.py)', implementation, re.IGNORECASE)
                    
                    if file_mentions and len(file_mentions) == len(code_blocks):
                        # Asignar nombres de archivo a bloques de código
                        for i, filename in enumerate(file_mentions):
                            if i < len(code_blocks):
                                file_changes[filename] = code_blocks[i]
                    else:
                        # No se pueden determinar nombres de archivo, usar nombres genéricos
                        for i, code_block in enumerate(code_blocks):
                            file_changes[f"improvement_{i+1}.py"] = code_block
            
            # Verificar si hay cambios para aplicar
            if not file_changes:
                logger.error("No se pudieron extraer cambios de la implementación generada")
                return {
                    "status": "error",
                    "error": "No se pudieron extraer cambios de la implementación",
                    "module": module_name
                }
            
            # Aplicar cambios
            applied_changes = []
            failed_changes = []
            
            for filename, new_code in file_changes.items():
                file_path = module_path / filename
                
                # Validar cambios
                if file_path.exists():
                    # Modificar archivo existente
                    with open(file_path, 'r', encoding='utf-8') as f:
                        original_code = f.read()
                    
                    validation = self._validate_code_changes(original_code, new_code)
                    
                    if not validation["valid"]:
                        logger.error(f"Validación fallida para {filename}: {validation['error']}")
                        failed_changes.append({
                            "file": filename,
                            "error": validation['error']
                        })
                        continue
                else:
                    # Nuevo archivo
                    try:
                        # Validar sintaxis
                        ast.parse(new_code)
                    except SyntaxError as e:
                        logger.error(f"Error de sintaxis en nuevo archivo {filename}: {e}")
                        failed_changes.append({
                            "file": filename,
                            "error": f"Error de sintaxis: {str(e)}"
                        })
                        continue
                
                # Aplicar cambio
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(new_code)
                    
                    applied_changes.append({
                        "file": filename,
                        "is_new": not file_path.exists() before the write operation
                    })
                    
                    logger.info(f"Cambios aplicados a {filename}")
                except Exception as e:
                    logger.error(f"Error al escribir {filename}: {e}")
                    failed_changes.append({
                        "file": filename,
                        "error": str(e)
                    })
            
            # Ejecutar pruebas si es necesario
            if self.safety_checks["run_tests_after_changes"] and applied_changes:
                test_results = self._run_tests(module_name)
                
                if not test_results["passed"]:
                    logger.error(f"Pruebas fallidas después de implementar mejora en {module_name}")
                    
                    # Restaurar desde backup
                    backups = sorted([d for d in self.versions_dir.iterdir() if d.is_dir() and d.name.startswith(f"before_improvement_")], 
                                    key=lambda x: int(x.name.split('_')[-1]) if x.name.split('_')[-1].isdigit() else 0,
                                    reverse=True)
                    
                    if backups:
                        latest_backup = backups[0]
                        logger.info(f"Restaurando desde backup {latest_backup}")
                        self._restore_from_backup(latest_backup)
                        
                        return {
                            "status": "error",
                            "error": "Pruebas fallidas después de implementar mejora",
                            "module": module_name,
                            "test_results": test_results,
                            "restored_from_backup": True
                        }
                    
                    return {
                        "status": "error",
                        "error": "Pruebas fallidas después de implementar mejora",
                        "module": module_name,
                        "test_results": test_results
                    }
            
            # Actualizar estadísticas
            self.total_optimizations += 1
            if applied_changes:
                self.successful_optimizations += 1
            self.last_optimization_time = time.time()
            
            # Guardar en historial
            optimization_record = {
                "type": "improvement_implementation",
                "module": module_name,
                "timestamp": time.time(),
                "duration": time.time() - start_time,
                "description": improvement_description,
                "applied_changes": applied_changes,
                "failed_changes": failed_changes
            }
            
            self.optimization_history.append(optimization_record)
            
            return {
                "status": "success" if applied_changes else "partial",
                "module": module_name,
                "applied_changes": applied_changes,
                "failed_changes": failed_changes,
                "implementation_time": time.time() - start_time
            }
        
        except Exception as e:
            logger.error(f"Error al implementar mejora: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e),
                "module": module_name
            }
    
    def analyze_and_improve_project(self, max_improvements: int = 3) -> Dict[str, Any]:
        """
        Analiza todo el proyecto y realiza mejoras automáticas.
        
        Args:
            max_improvements: Número máximo de mejoras a realizar.
            
        Returns:
            Diccionario con resultado del proceso.
        """
        if not self.code_analyzer:
            logger.error("Code Analyzer no disponible para análisis del proyecto")
            return {
                "status": "error",
                "error": "Code Analyzer no disponible"
            }
        
        start_time = time.time()
        
        try:
            logger.info(f"Iniciando análisis y mejora automática del proyecto (máx. {max_improvements} mejoras)")
            
            # Crear backup del proyecto
            if self.safety_checks["backup_before_changes"]:
                self._create_backup(None, f"before_auto_improvement_{int(time.time())}")
            
            # Analizar proyecto
            project_analysis = self.code_analyzer.analyze_project()
            
            if project_analysis['status'] != 'success':
                logger.error(f"Error al analizar proyecto: {project_analysis.get('error', 'Error desconocido')}")
                return {
                    "status": "error",
                    "error": project_analysis.get('error', 'Error en análisis')
                }
            
            # Identificar archivos con más problemas
            problem_files = []
            
            for module_analysis in project_analysis['module_analyses']:
                if module_analysis['status'] != 'success':
                    continue
                
                for file_analysis in module_analysis.get('file_analyses', []):
                    if file_analysis['status'] != 'success':
                        continue
                    
                    if file_analysis['total_issues'] > 0 and file_analysis['quality_score'] < 7.0:
                        problem_files.append({
                            "file_path": file_analysis['file_path'],
                            "total_issues": file_analysis['total_issues'],
                            "quality_score": file_analysis['quality_score']
                        })
            
            # Ordenar por número de problemas (descendente)
            problem_files.sort(key=lambda x: x['total_issues'], reverse=True)
            
            # Limitar a los archivos con más problemas
            problem_files = problem_files[:max_improvements]
            
            if not problem_files:
                logger.info("No se encontraron archivos con problemas significativos")
                return {
                    "status": "success",
                    "message": "No se encontraron archivos con problemas significativos",
                    "project_quality": project_analysis['avg_quality_score'],
                    "improvements_made": 0
                }
            
            # Realizar mejoras
            improvements = []
            
            for file_info in problem_files:
                file_path = Path(file_info['file_path'])
                
                logger.info(f"Refactorizando archivo con problemas: {file_path}")
                
                result = self.refactor_code(file_path)
                
                improvements.append({
                    "file_path": file_info['file_path'],
                    "original_quality": file_info['quality_score'],
                    "new_quality": result.get('new_quality'),
                    "status": result['status'],
                    "changes_made": result.get('changes_made', False)
                })
                
                # Esperar un poco entre refactorizaciones
                time.sleep(2)
            
            # Contar mejoras exitosas
            successful_improvements = sum(1 for imp in improvements if imp['status'] == 'success' and imp['changes_made'])
            
            # Actualizar estadísticas
            self.total_optimizations += 1
            if successful_improvements > 0:
                self.successful_optimizations += 1
            self.last_optimization_time = time.time()
            
            # Guardar en historial
            optimization_record = {
                "type": "auto_improvement",
                "timestamp": time.time(),
                "duration": time.time() - start_time,
                "improvements": improvements,
                "successful_count": successful_improvements
            }
            
            self.optimization_history.append(optimization_record)
            
            return {
                "status": "success",
                "project_quality": project_analysis['avg_quality_score'],
                "improvements": improvements,
                "successful_improvements": successful_improvements,
                "total_time": time.time() - start_time
            }
        
        except Exception as e:
            logger.error(f"Error en análisis y mejora automática: {e}", exc_info=True)
            return {
                "status": "error",
                "error": str(e)
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas del optimizador automático.
        
        Returns:
            Diccionario con estadísticas.
        """
        stats = {
            "total_optimizations": self.total_optimizations,
            "successful_optimizations": self.successful_optimizations,
            "success_rate": self.successful_optimizations / max(1, self.total_optimizations),
            "last_optimization_time": self.last_optimization_time,
            "recent_history": self.optimization_history[-10:] if self.optimization_history else [],
            "safety_checks": self.safety_checks,
            "evolution_engine_available": self.evolution_engine is not None,
            "code_analyzer_available": self.code_analyzer is not None,
            "llm_manager_available": self.llm_manager is not None,
        }
        
        return stats
