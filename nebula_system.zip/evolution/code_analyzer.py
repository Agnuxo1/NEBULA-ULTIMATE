"""
Implementación del Analizador de Código para NEBULA.

Esta clase proporciona funcionalidades para analizar, evaluar y sugerir mejoras
en el código fuente del sistema NEBULA.
"""

import logging
import time
import os
import re
import ast
import inspect
import importlib
import pkgutil
from typing import Any, Dict, List, Optional, Tuple, Union, Set
from pathlib import Path
import json

from utils.config import PARAMETERS
from utils.helpers import safe_loop

logger = logging.getLogger("NEBULA.CodeAnalyzer")

class CodeAnalyzer:
    """
    Analizador de código que evalúa la calidad, eficiencia y estructura
    del código fuente del sistema NEBULA.
    
    Características:
    - Análisis estático de código
    - Detección de patrones y anti-patrones
    - Evaluación de complejidad y mantenibilidad
    - Sugerencias de mejora y optimización
    """
    
    def __init__(self, llm_manager=None):
        """
        Inicializa el analizador de código.
        
        Args:
            llm_manager: Gestor de modelos LLM para análisis avanzado.
        """
        logger.info("Inicializando CodeAnalyzer...")
        self.llm_manager = llm_manager
        
        # Directorio raíz del proyecto
        self.project_root = Path(PARAMETERS["PROJECT_ROOT"])
        
        # Directorio para informes
        self.reports_dir = PARAMETERS["BACKUP_DIRECTORY"] / "code_analysis"
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # Historial de análisis
        self.analysis_history = []
        
        # Contadores y estadísticas
        self.total_analyses = 0
        self.last_analysis_time = 0
        
        # Patrones y reglas
        self._initialize_patterns()
        
        logger.info("CodeAnalyzer inicializado correctamente.")
    
    def _initialize_patterns(self):
        """Inicializa patrones y reglas para análisis de código."""
        # Patrones de código problemático
        self.code_smells = {
            "long_method": {
                "description": "Método demasiado largo (más de 50 líneas)",
                "severity": "medium"
            },
            "too_many_parameters": {
                "description": "Método con demasiados parámetros (más de 5)",
                "severity": "medium"
            },
            "complex_conditional": {
                "description": "Condicional demasiado complejo",
                "severity": "high"
            },
            "duplicate_code": {
                "description": "Código duplicado",
                "severity": "high"
            },
            "global_variable": {
                "description": "Uso de variables globales",
                "severity": "medium"
            },
            "nested_loops": {
                "description": "Bucles anidados profundos",
                "severity": "medium"
            },
            "large_class": {
                "description": "Clase demasiado grande (más de 300 líneas)",
                "severity": "medium"
            },
            "commented_code": {
                "description": "Código comentado",
                "severity": "low"
            },
            "magic_number": {
                "description": "Número mágico (constante sin nombre)",
                "severity": "low"
            },
            "empty_catch": {
                "description": "Bloque catch vacío",
                "severity": "high"
            }
        }
        
        # Patrones de buenas prácticas
        self.good_practices = {
            "docstring": {
                "description": "Documentación adecuada",
                "importance": "high"
            },
            "type_hints": {
                "description": "Uso de type hints",
                "importance": "medium"
            },
            "error_handling": {
                "description": "Manejo adecuado de errores",
                "importance": "high"
            },
            "modular_design": {
                "description": "Diseño modular",
                "importance": "high"
            },
            "consistent_naming": {
                "description": "Nomenclatura consistente",
                "importance": "medium"
            },
            "unit_tests": {
                "description": "Pruebas unitarias",
                "importance": "high"
            }
        }
    
    def _get_python_files(self, directory: Path) -> List[Path]:
        """
        Obtiene todos los archivos Python en un directorio y sus subdirectorios.
        
        Args:
            directory: Directorio a analizar.
            
        Returns:
            Lista de rutas a archivos Python.
        """
        python_files = []
        
        for root, _, files in os.walk(directory):
            for file in files:
                if file.endswith('.py'):
                    python_files.append(Path(root) / file)
        
        return python_files
    
    def _parse_file(self, file_path: Path) -> Optional[ast.Module]:
        """
        Parsea un archivo Python a un AST.
        
        Args:
            file_path: Ruta al archivo.
            
        Returns:
            AST del archivo o None si hay error.
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return ast.parse(content, filename=str(file_path))
        except Exception as e:
            logger.error(f"Error al parsear {file_path}: {e}")
            return None
    
    def _count_lines(self, file_path: Path) -> Dict[str, int]:
        """
        Cuenta líneas de código, comentarios y espacios en blanco.
        
        Args:
            file_path: Ruta al archivo.
            
        Returns:
            Diccionario con conteos.
        """
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            total_lines = len(lines)
            blank_lines = sum(1 for line in lines if line.strip() == '')
            comment_lines = sum(1 for line in lines if line.strip().startswith('#'))
            
            # Detectar líneas de docstring
            content = ''.join(lines)
            tree = ast.parse(content)
            
            docstring_lines = 0
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.ClassDef, ast.Module)):
                    if ast.get_docstring(node):
                        docstring = ast.get_docstring(node)
                        docstring_lines += len(docstring.split('\n'))
            
            code_lines = total_lines - blank_lines - comment_lines - docstring_lines
            
            return {
                'total': total_lines,
                'code': code_lines,
                'comments': comment_lines,
                'docstrings': docstring_lines,
                'blank': blank_lines
            }
        except Exception as e:
            logger.error(f"Error al contar líneas en {file_path}: {e}")
            return {
                'total': 0,
                'code': 0,
                'comments': 0,
                'docstrings': 0,
                'blank': 0
            }
    
    def _calculate_complexity(self, node: ast.AST) -> int:
        """
        Calcula la complejidad ciclomática de un nodo AST.
        
        Args:
            node: Nodo AST.
            
        Returns:
            Complejidad ciclomática.
        """
        complexity = 1  # Base complexity
        
        # Incrementar por cada estructura de control
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For)):
                complexity += 1
            elif isinstance(child, ast.BoolOp) and isinstance(child.op, ast.And):
                complexity += len(child.values) - 1
            elif isinstance(child, ast.BoolOp) and isinstance(child.op, ast.Or):
                complexity += len(child.values) - 1
        
        return complexity
    
    def _analyze_function(self, node: ast.FunctionDef) -> Dict[str, Any]:
        """
        Analiza una función o método.
        
        Args:
            node: Nodo AST de la función.
            
        Returns:
            Diccionario con análisis.
        """
        # Obtener código fuente
        source_lines = ast.get_source_segment(node.parent, node).split('\n')
        
        # Contar líneas
        total_lines = len(source_lines)
        
        # Obtener docstring
        docstring = ast.get_docstring(node)
        has_docstring = docstring is not None
        
        # Calcular complejidad
        complexity = self._calculate_complexity(node)
        
        # Analizar parámetros
        params = []
        for arg in node.args.args:
            param = {
                'name': arg.arg,
                'has_type': arg.annotation is not None
            }
            if arg.annotation:
                param['type'] = ast.unparse(arg.annotation)
            params.append(param)
        
        # Verificar return type
        has_return_type = node.returns is not None
        return_type = ast.unparse(node.returns) if node.returns else None
        
        # Detectar problemas
        issues = []
        
        # Método largo
        if total_lines > 50:
            issues.append({
                'type': 'long_method',
                'description': f"Función demasiado larga ({total_lines} líneas)",
                'severity': 'medium'
            })
        
        # Demasiados parámetros
        if len(params) > 5:
            issues.append({
                'type': 'too_many_parameters',
                'description': f"Demasiados parámetros ({len(params)})",
                'severity': 'medium'
            })
        
        # Complejidad alta
        if complexity > 10:
            issues.append({
                'type': 'high_complexity',
                'description': f"Complejidad ciclomática alta ({complexity})",
                'severity': 'high'
            })
        
        # Sin docstring
        if not has_docstring:
            issues.append({
                'type': 'missing_docstring',
                'description': "Falta docstring",
                'severity': 'medium'
            })
        
        # Detectar bucles anidados
        nested_loops = []
        for_loops = []
        
        for child in ast.walk(node):
            if isinstance(child, (ast.For, ast.While)):
                for_loops.append(child)
        
        # Verificar anidamiento
        for loop in for_loops:
            nested_count = 0
            for inner_loop in for_loops:
                if inner_loop != loop:
                    # Verificar si inner_loop está dentro de loop
                    if loop.lineno <= inner_loop.lineno and loop.end_lineno >= inner_loop.end_lineno:
                        nested_count += 1
            
            if nested_count > 1:
                nested_loops.append({
                    'line': loop.lineno,
                    'nested_count': nested_count
                })
        
        if nested_loops:
            issues.append({
                'type': 'nested_loops',
                'description': f"Bucles anidados detectados ({len(nested_loops)})",
                'severity': 'medium',
                'details': nested_loops
            })
        
        return {
            'name': node.name,
            'lines': total_lines,
            'complexity': complexity,
            'has_docstring': has_docstring,
            'docstring_quality': self._evaluate_docstring(docstring) if has_docstring else 0,
            'params': params,
            'param_count': len(params),
            'type_hint_coverage': sum(1 for p in params if p['has_type']) / max(1, len(params)),
            'has_return_type': has_return_type,
            'return_type': return_type,
            'issues': issues
        }
    
    def _analyze_class(self, node: ast.ClassDef) -> Dict[str, Any]:
        """
        Analiza una clase.
        
        Args:
            node: Nodo AST de la clase.
            
        Returns:
            Diccionario con análisis.
        """
        # Obtener código fuente
        source_lines = ast.get_source_segment(node.parent, node).split('\n')
        
        # Contar líneas
        total_lines = len(source_lines)
        
        # Obtener docstring
        docstring = ast.get_docstring(node)
        has_docstring = docstring is not None
        
        # Analizar métodos
        methods = []
        for child in node.body:
            if isinstance(child, ast.FunctionDef):
                methods.append(self._analyze_function(child))
        
        # Detectar problemas
        issues = []
        
        # Clase grande
        if total_lines > 300:
            issues.append({
                'type': 'large_class',
                'description': f"Clase demasiado grande ({total_lines} líneas)",
                'severity': 'medium'
            })
        
        # Sin docstring
        if not has_docstring:
            issues.append({
                'type': 'missing_docstring',
                'description': "Falta docstring",
                'severity': 'medium'
            })
        
        # Demasiados métodos
        if len(methods) > 20:
            issues.append({
                'type': 'too_many_methods',
                'description': f"Demasiados métodos ({len(methods)})",
                'severity': 'medium'
            })
        
        return {
            'name': node.name,
            'lines': total_lines,
            'has_docstring': has_docstring,
            'docstring_quality': self._evaluate_docstring(docstring) if has_docstring else 0,
            'methods': methods,
            'method_count': len(methods),
            'issues': issues,
            'inheritance': [ast.unparse(base) for base in node.bases] if node.bases else []
        }
    
    def _evaluate_docstring(self, docstring: Optional[str]) -> float:
        """
        Evalúa la calidad de un docstring.
        
        Args:
            docstring: Docstring a evaluar.
            
        Returns:
            Puntuación de calidad (0-1).
        """
        if not docstring:
            return 0.0
        
        score = 0.0
        max_score = 4.0
        
        # Longitud mínima
        if len(docstring) > 10:
            score += 1.0
        
        # Descripción de parámetros
        if re.search(r'Args:|Parameters:', docstring):
            score += 1.0
        
        # Descripción de retorno
        if re.search(r'Returns:|Return:', docstring):
            score += 1.0
        
        # Ejemplos o notas adicionales
        if re.search(r'Example|Note|Usage:', docstring):
            score += 1.0
        
        return score / max_score
    
    def _detect_code_smells(self, file_path: Path, tree: ast.Module) -> List[Dict[str, Any]]:
        """
        Detecta code smells en un archivo.
        
        Args:
            file_path: Ruta al archivo.
            tree: AST del archivo.
            
        Returns:
            Lista de code smells detectados.
        """
        smells = []
        
        # Leer contenido del archivo
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            lines = content.split('\n')
        
        # Detectar código comentado
        commented_code_pattern = re.compile(r'^\s*#\s*(def|class|if|for|while|return|import|from)')
        for i, line in enumerate(lines):
            if commented_code_pattern.match(line):
                smells.append({
                    'type': 'commented_code',
                    'line': i + 1,
                    'description': "Código comentado",
                    'severity': 'low'
                })
        
        # Detectar números mágicos
        magic_number_pattern = re.compile(r'\b[0-9]+\b')
        for i, line in enumerate(lines):
            # Ignorar líneas de comentarios y docstrings
            if line.strip().startswith('#') or line.strip().startswith('"""') or line.strip().startswith("'''"):
                continue
            
            # Buscar números que no sean 0, 1, -1
            for match in magic_number_pattern.finditer(line):
                num = match.group(0)
                if num not in ['0', '1', '-1'] and len(num) > 1:
                    # Verificar que no sea parte de una asignación de constante
                    if not re.match(r'^\s*[A-Z][A-Z0-9_]*\s*=', line):
                        smells.append({
                            'type': 'magic_number',
                            'line': i + 1,
                            'description': f"Número mágico: {num}",
                            'severity': 'low'
                        })
        
        # Detectar bloques catch vacíos
        for node in ast.walk(tree):
            if isinstance(node, ast.ExceptHandler):
                if not node.body or (len(node.body) == 1 and isinstance(node.body[0], ast.Pass)):
                    smells.append({
                        'type': 'empty_catch',
                        'line': node.lineno,
                        'description': "Bloque except vacío",
                        'severity': 'high'
                    })
        
        # Detectar variables globales
        for node in ast.walk(tree):
            if isinstance(node, ast.Global):
                for name in node.names:
                    smells.append({
                        'type': 'global_variable',
                        'line': node.lineno,
                        'description': f"Uso de variable global: {name}",
                        'severity': 'medium'
                    })
        
        # Detectar condicionales complejos
        for node in ast.walk(tree):
            if isinstance(node, ast.If):
                # Contar operadores booleanos
                bool_ops = 0
                for subnode in ast.walk(node.test):
                    if isinstance(subnode, ast.BoolOp):
                        bool_ops += len(subnode.values) - 1
                
                if bool_ops > 3:
                    smells.append({
                        'type': 'complex_conditional',
                        'line': node.lineno,
                        'description': f"Condicional complejo con {bool_ops} operaciones booleanas",
                        'severity': 'high'
                    })
        
        return smells
    
    @safe_loop(max_retries=2, delay=1)
    def analyze_file(self, file_path: Path) -> Dict[str, Any]:
        """
        Analiza un archivo Python.
        
        Args:
            file_path: Ruta al archivo.
            
        Returns:
            Diccionario con análisis.
        """
        start_time = time.time()
        
        logger.info(f"Analizando archivo: {file_path}")
        
        # Verificar existencia del archivo
        if not file_path.exists():
            logger.error(f"Archivo no encontrado: {file_path}")
            return {
                'status': 'error',
                'error': 'Archivo no encontrado',
                'file_path': str(file_path)
            }
        
        try:
            # Parsear archivo
            tree = self._parse_file(file_path)
            if not tree:
                return {
                    'status': 'error',
                    'error': 'Error al parsear archivo',
                    'file_path': str(file_path)
                }
            
            # Contar líneas
            line_counts = self._count_lines(file_path)
            
            # Analizar clases
            classes = []
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, ast.ClassDef):
                    classes.append(self._analyze_class(node))
            
            # Analizar funciones de nivel superior
            functions = []
            for node in ast.iter_child_nodes(tree):
                if isinstance(node, ast.FunctionDef):
                    functions.append(self._analyze_function(node))
            
            # Detectar code smells
            code_smells = self._detect_code_smells(file_path, tree)
            
            # Calcular métricas generales
            total_issues = sum(len(cls['issues']) for cls in classes) + sum(len(func['issues']) for func in functions) + len(code_smells)
            
            # Calcular puntuación de calidad
            quality_score = self._calculate_quality_score(line_counts, classes, functions, code_smells)
            
            # Preparar resultado
            result = {
                'status': 'success',
                'file_path': str(file_path),
                'line_counts': line_counts,
                'classes': classes,
                'functions': functions,
                'code_smells': code_smells,
                'total_issues': total_issues,
                'quality_score': quality_score,
                'analysis_time': time.time() - start_time
            }
            
            # Actualizar estadísticas
            self.total_analyses += 1
            self.last_analysis_time = time.time()
            
            return result
        
        except Exception as e:
            logger.error(f"Error al analizar archivo {file_path}: {e}", exc_info=True)
            return {
                'status': 'error',
                'error': str(e),
                'file_path': str(file_path)
            }
    
    def _calculate_quality_score(self, line_counts: Dict[str, int], classes: List[Dict[str, Any]], 
                               functions: List[Dict[str, Any]], code_smells: List[Dict[str, Any]]) -> float:
        """
        Calcula una puntuación de calidad para el código.
        
        Args:
            line_counts: Conteo de líneas.
            classes: Análisis de clases.
            functions: Análisis de funciones.
            code_smells: Code smells detectados.
            
        Returns:
            Puntuación de calidad (0-10).
        """
        score = 10.0  # Puntuación inicial perfecta
        
        # Penalizar por code smells según severidad
        for smell in code_smells:
            if smell['severity'] == 'high':
                score -= 0.5
            elif smell['severity'] == 'medium':
                score -= 0.3
            else:
                score -= 0.1
        
        # Penalizar por problemas en clases
        for cls in classes:
            for issue in cls['issues']:
                if issue['severity'] == 'high':
                    score -= 0.5
                elif issue['severity'] == 'medium':
                    score -= 0.3
                else:
                    score -= 0.1
        
        # Penalizar por problemas en funciones
        for func in functions:
            for issue in func['issues']:
                if issue['severity'] == 'high':
                    score -= 0.5
                elif issue['severity'] == 'medium':
                    score -= 0.3
                else:
                    score -= 0.1
        
        # Bonificar por buena documentación
        doc_ratio = (line_counts['docstrings'] + line_counts['comments']) / max(1, line_counts['total'])
        if doc_ratio > 0.2:
            score += 1.0
        elif doc_ratio > 0.1:
            score += 0.5
        
        # Bonificar por docstrings de calidad en clases
        for cls in classes:
            if cls['has_docstring'] and cls['docstring_quality'] > 0.7:
                score += 0.2
        
        # Bonificar por docstrings de calidad en funciones
        for func in functions:
            if func['has_docstring'] and func['docstring_quality'] > 0.7:
                score += 0.1
        
        # Bonificar por uso de type hints
        type_hint_coverage = 0.0
        total_params = 0
        
        for func in functions:
            total_params += func['param_count']
            type_hint_coverage += func['type_hint_coverage'] * func['param_count']
        
        if total_params > 0:
            type_hint_coverage /= total_params
            
            if type_hint_coverage > 0.8:
                score += 1.0
            elif type_hint_coverage > 0.5:
                score += 0.5
        
        # Limitar puntuación al rango 0-10
        return max(0.0, min(10.0, score))
    
    def analyze_module(self, module_path: Path) -> Dict[str, Any]:
        """
        Analiza un módulo completo (directorio con archivos Python).
        
        Args:
            module_path: Ruta al módulo.
            
        Returns:
            Diccionario con análisis.
        """
        start_time = time.time()
        
        logger.info(f"Analizando módulo: {module_path}")
        
        # Verificar existencia del directorio
        if not module_path.exists() or not module_path.is_dir():
            logger.error(f"Directorio no encontrado: {module_path}")
            return {
                'status': 'error',
                'error': 'Directorio no encontrado',
                'module_path': str(module_path)
            }
        
        try:
            # Obtener archivos Python
            python_files = self._get_python_files(module_path)
            
            # Analizar cada archivo
            file_analyses = []
            for file_path in python_files:
                file_analysis = self.analyze_file(file_path)
                file_analyses.append(file_analysis)
            
            # Calcular métricas agregadas
            total_files = len(file_analyses)
            successful_analyses = sum(1 for analysis in file_analyses if analysis['status'] == 'success')
            
            if successful_analyses == 0:
                logger.error(f"No se pudo analizar ningún archivo en {module_path}")
                return {
                    'status': 'error',
                    'error': 'No se pudo analizar ningún archivo',
                    'module_path': str(module_path)
                }
            
            # Agregar conteos de líneas
            total_lines = sum(analysis['line_counts']['total'] for analysis in file_analyses if analysis['status'] == 'success')
            code_lines = sum(analysis['line_counts']['code'] for analysis in file_analyses if analysis['status'] == 'success')
            comment_lines = sum(analysis['line_counts']['comments'] for analysis in file_analyses if analysis['status'] == 'success')
            docstring_lines = sum(analysis['line_counts']['docstrings'] for analysis in file_analyses if analysis['status'] == 'success')
            blank_lines = sum(analysis['line_counts']['blank'] for analysis in file_analyses if analysis['status'] == 'success')
            
            # Agregar conteos de clases y funciones
            total_classes = sum(len(analysis['classes']) for analysis in file_analyses if analysis['status'] == 'success')
            total_functions = sum(len(analysis['functions']) for analysis in file_analyses if analysis['status'] == 'success')
            
            # Agregar conteos de problemas
            total_issues = sum(analysis['total_issues'] for analysis in file_analyses if analysis['status'] == 'success')
            
            # Calcular puntuación de calidad promedio
            avg_quality = sum(analysis['quality_score'] for analysis in file_analyses if analysis['status'] == 'success') / successful_analyses
            
            # Identificar archivos con más problemas
            problem_files = sorted(
                [analysis for analysis in file_analyses if analysis['status'] == 'success'],
                key=lambda x: x['total_issues'],
                reverse=True
            )[:5]  # Top 5 archivos con más problemas
            
            # Preparar resultado
            result = {
                'status': 'success',
                'module_path': str(module_path),
                'total_files': total_files,
                'analyzed_files': successful_analyses,
                'line_counts': {
                    'total': total_lines,
                    'code': code_lines,
                    'comments': comment_lines,
                    'docstrings': docstring_lines,
                    'blank': blank_lines
                },
                'total_classes': total_classes,
                'total_functions': total_functions,
                'total_issues': total_issues,
                'avg_quality_score': avg_quality,
                'problem_files': [
                    {
                        'file_path': file['file_path'],
                        'total_issues': file['total_issues'],
                        'quality_score': file['quality_score']
                    }
                    for file in problem_files
                ],
                'file_analyses': file_analyses,
                'analysis_time': time.time() - start_time
            }
            
            # Guardar resultado
            self._save_analysis_report(result, f"module_analysis_{module_path.name}_{int(time.time())}.json")
            
            # Actualizar historial
            self.analysis_history.append({
                'type': 'module',
                'path': str(module_path),
                'timestamp': time.time(),
                'total_files': total_files,
                'total_issues': total_issues,
                'avg_quality_score': avg_quality
            })
            
            return result
        
        except Exception as e:
            logger.error(f"Error al analizar módulo {module_path}: {e}", exc_info=True)
            return {
                'status': 'error',
                'error': str(e),
                'module_path': str(module_path)
            }
    
    def analyze_project(self) -> Dict[str, Any]:
        """
        Analiza todo el proyecto NEBULA.
        
        Returns:
            Diccionario con análisis.
        """
        start_time = time.time()
        
        logger.info("Analizando proyecto NEBULA completo")
        
        try:
            # Obtener módulos principales
            modules = [d for d in self.project_root.iterdir() if d.is_dir() and 
                      (d / "__init__.py").exists() and not d.name.startswith('.')]
            
            # Analizar cada módulo
            module_analyses = []
            for module_path in modules:
                module_analysis = self.analyze_module(module_path)
                module_analyses.append(module_analysis)
            
            # Calcular métricas agregadas
            total_modules = len(module_analyses)
            successful_analyses = sum(1 for analysis in module_analyses if analysis['status'] == 'success')
            
            if successful_analyses == 0:
                logger.error("No se pudo analizar ningún módulo")
                return {
                    'status': 'error',
                    'error': 'No se pudo analizar ningún módulo'
                }
            
            # Agregar conteos
            total_files = sum(analysis['total_files'] for analysis in module_analyses if analysis['status'] == 'success')
            analyzed_files = sum(analysis['analyzed_files'] for analysis in module_analyses if analysis['status'] == 'success')
            
            total_lines = sum(analysis['line_counts']['total'] for analysis in module_analyses if analysis['status'] == 'success')
            code_lines = sum(analysis['line_counts']['code'] for analysis in module_analyses if analysis['status'] == 'success')
            comment_lines = sum(analysis['line_counts']['comments'] for analysis in module_analyses if analysis['status'] == 'success')
            docstring_lines = sum(analysis['line_counts']['docstrings'] for analysis in module_analyses if analysis['status'] == 'success')
            blank_lines = sum(analysis['line_counts']['blank'] for analysis in module_analyses if analysis['status'] == 'success')
            
            total_classes = sum(analysis['total_classes'] for analysis in module_analyses if analysis['status'] == 'success')
            total_functions = sum(analysis['total_functions'] for analysis in module_analyses if analysis['status'] == 'success')
            
            total_issues = sum(analysis['total_issues'] for analysis in module_analyses if analysis['status'] == 'success')
            
            # Calcular puntuación de calidad promedio
            avg_quality = sum(analysis['avg_quality_score'] for analysis in module_analyses if analysis['status'] == 'success') / successful_analyses
            
            # Identificar módulos con más problemas
            problem_modules = sorted(
                [analysis for analysis in module_analyses if analysis['status'] == 'success'],
                key=lambda x: x['total_issues'],
                reverse=True
            )[:3]  # Top 3 módulos con más problemas
            
            # Preparar resultado
            result = {
                'status': 'success',
                'project_root': str(self.project_root),
                'total_modules': total_modules,
                'analyzed_modules': successful_analyses,
                'total_files': total_files,
                'analyzed_files': analyzed_files,
                'line_counts': {
                    'total': total_lines,
                    'code': code_lines,
                    'comments': comment_lines,
                    'docstrings': docstring_lines,
                    'blank': blank_lines
                },
                'total_classes': total_classes,
                'total_functions': total_functions,
                'total_issues': total_issues,
                'avg_quality_score': avg_quality,
                'problem_modules': [
                    {
                        'module_path': module['module_path'],
                        'total_issues': module['total_issues'],
                        'avg_quality_score': module['avg_quality_score'],
                        'total_files': module['total_files']
                    }
                    for module in problem_modules
                ],
                'module_analyses': module_analyses,
                'analysis_time': time.time() - start_time
            }
            
            # Guardar resultado
            self._save_analysis_report(result, f"project_analysis_{int(time.time())}.json")
            
            # Actualizar historial
            self.analysis_history.append({
                'type': 'project',
                'timestamp': time.time(),
                'total_modules': total_modules,
                'total_files': total_files,
                'total_issues': total_issues,
                'avg_quality_score': avg_quality
            })
            
            return result
        
        except Exception as e:
            logger.error(f"Error al analizar proyecto: {e}", exc_info=True)
            return {
                'status': 'error',
                'error': str(e)
            }
    
    def _save_analysis_report(self, report: Dict[str, Any], filename: str):
        """
        Guarda un informe de análisis.
        
        Args:
            report: Informe a guardar.
            filename: Nombre del archivo.
        """
        try:
            report_path = self.reports_dir / filename
            with open(report_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2)
            logger.info(f"Informe guardado en {report_path}")
        except Exception as e:
            logger.error(f"Error al guardar informe: {e}")
    
    def generate_improvement_suggestions(self, analysis_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Genera sugerencias de mejora basadas en un análisis.
        
        Args:
            analysis_result: Resultado de análisis.
            
        Returns:
            Diccionario con sugerencias.
        """
        if analysis_result['status'] != 'success':
            return {
                'status': 'error',
                'error': 'El análisis no fue exitoso'
            }
        
        suggestions = {
            'status': 'success',
            'general_suggestions': [],
            'specific_suggestions': []
        }
        
        # Sugerencias generales basadas en métricas
        if 'line_counts' in analysis_result:
            doc_ratio = (analysis_result['line_counts']['docstrings'] + analysis_result['line_counts']['comments']) / max(1, analysis_result['line_counts']['total'])
            
            if doc_ratio < 0.1:
                suggestions['general_suggestions'].append({
                    'category': 'documentation',
                    'description': 'Mejorar la documentación del código. La proporción de comentarios y docstrings es baja.',
                    'importance': 'high'
                })
        
        if 'avg_quality_score' in analysis_result and analysis_result['avg_quality_score'] < 6.0:
            suggestions['general_suggestions'].append({
                'category': 'code_quality',
                'description': f"La puntuación de calidad general ({analysis_result['avg_quality_score']:.1f}/10) es baja. Considerar una revisión general del código.",
                'importance': 'high'
            })
        
        # Sugerencias específicas basadas en problemas
        if 'file_analyses' in analysis_result:
            for file_analysis in analysis_result['file_analyses']:
                if file_analysis['status'] != 'success':
                    continue
                
                file_suggestions = []
                
                # Sugerencias basadas en code smells
                for smell in file_analysis['code_smells']:
                    suggestion = {
                        'file': file_analysis['file_path'],
                        'line': smell['line'],
                        'category': smell['type'],
                        'description': smell['description'],
                        'importance': 'high' if smell['severity'] == 'high' else 'medium' if smell['severity'] == 'medium' else 'low'
                    }
                    file_suggestions.append(suggestion)
                
                # Sugerencias basadas en problemas de clases
                for cls in file_analysis['classes']:
                    for issue in cls['issues']:
                        suggestion = {
                            'file': file_analysis['file_path'],
                            'class': cls['name'],
                            'category': issue['type'],
                            'description': issue['description'],
                            'importance': 'high' if issue['severity'] == 'high' else 'medium' if issue['severity'] == 'medium' else 'low'
                        }
                        file_suggestions.append(suggestion)
                
                # Sugerencias basadas en problemas de funciones
                for func in file_analysis['functions']:
                    for issue in func['issues']:
                        suggestion = {
                            'file': file_analysis['file_path'],
                            'function': func['name'],
                            'category': issue['type'],
                            'description': issue['description'],
                            'importance': 'high' if issue['severity'] == 'high' else 'medium' if issue['severity'] == 'medium' else 'low'
                        }
                        file_suggestions.append(suggestion)
                
                # Añadir sugerencias del archivo si hay alguna
                if file_suggestions:
                    suggestions['specific_suggestions'].extend(file_suggestions)
        
        # Ordenar sugerencias por importancia
        suggestions['general_suggestions'].sort(key=lambda x: 0 if x['importance'] == 'high' else 1 if x['importance'] == 'medium' else 2)
        suggestions['specific_suggestions'].sort(key=lambda x: 0 if x['importance'] == 'high' else 1 if x['importance'] == 'medium' else 2)
        
        return suggestions
    
    def generate_llm_suggestions(self, file_path: Path) -> Dict[str, Any]:
        """
        Genera sugerencias de mejora utilizando LLM.
        
        Args:
            file_path: Ruta al archivo a analizar.
            
        Returns:
            Diccionario con sugerencias.
        """
        if not self.llm_manager:
            return {
                'status': 'error',
                'error': 'LLM Manager no disponible'
            }
        
        try:
            # Leer archivo
            with open(file_path, 'r', encoding='utf-8') as f:
                code = f.read()
            
            # Limitar tamaño para el LLM
            if len(code) > 8000:
                code = code[:8000] + "\n# ... (código truncado) ..."
            
            # Generar prompt
            prompt = f"""Analiza el siguiente código Python y proporciona sugerencias de mejora.
Enfócate en:
1. Calidad del código y buenas prácticas
2. Optimización de rendimiento
3. Mejoras de diseño y arquitectura
4. Documentación y legibilidad

Código a analizar:
```python
{code}
```

Proporciona sugerencias específicas y concretas, indicando la línea o sección del código cuando sea posible.
"""
            
            # Generar sugerencias
            suggestions_text = self.llm_manager.generate_text(prompt, max_length=800, model_size="large")
            
            return {
                'status': 'success',
                'file_path': str(file_path),
                'llm_suggestions': suggestions_text
            }
        
        except Exception as e:
            logger.error(f"Error al generar sugerencias LLM para {file_path}: {e}")
            return {
                'status': 'error',
                'error': str(e),
                'file_path': str(file_path)
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Obtiene estadísticas del analizador de código.
        
        Returns:
            Diccionario con estadísticas.
        """
        stats = {
            "total_analyses": self.total_analyses,
            "last_analysis_time": self.last_analysis_time,
            "analysis_history": self.analysis_history[-10:] if self.analysis_history else [],
            "llm_available": self.llm_manager is not None,
        }
        
        return stats
