"""
Módulo de procesamiento de lenguaje para NEBULA.

Este módulo contiene las clases para procesamiento de lenguaje natural,
incluyendo generación de texto, respuesta a preguntas y gestión de modelos LLM.
"""

__all__ = ["llm_manager", "text_generator", "qa_system"]
