"""
Módulo de sistemas de conocimiento para NEBULA.

Este módulo contiene las clases para representación y gestión del conocimiento,
incluyendo el grafo de conocimiento y la memoria holográfica.
"""

__all__ = ["knowledge_graph", "holographic_memory", "optical_processor"]
